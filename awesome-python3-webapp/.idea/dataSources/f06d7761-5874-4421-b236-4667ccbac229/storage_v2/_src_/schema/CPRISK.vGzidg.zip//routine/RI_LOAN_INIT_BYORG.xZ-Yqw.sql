CREATE procedure ri_loan_init_byOrg  is
p_org  varchar2(4);
 p_cntt_code  ri_loan_baseinfo.cntt_code%type;

 --???????????????
 cursor normal_rs(l_org in varchar2)is
    select distinct cntt_code from ri_loan_baseinfo a
    where a.old_cntt_code is null and a.org_code=l_org;
begin
p_org:='1600';

 open normal_rs(p_org);
  loop
    fetch normal_rs into p_cntt_code;
    EXIT WHEN normal_rs%NOTFOUND;
--??????
    delete from ri_loan_baseinfo where cntt_code=p_cntt_code;
    commit;
    insert into ri_loan_baseinfo
(CNTT_ID,CNTT_CODE,YEAR,ORG_CODE,          ORG_NAME,BORROWER_ID,          BORROWER_NAME,PROD_CODE, IS_STANDARD,LOAN_AMT,INST_RATE,APPROP_RATE,OVERDUE_RATE,USAGE,START_DATE,END_DATE,INST_PAY_TYPE,REPAY_SOURCE, SUPPLEMENT, SIGN_DATE, LOAN_TERM, INVT_CLS, INVT_SUB_CLS, TERM_CLS, USAGE_CLS, USAGE_SUB_CLS, CREDIT_FLAG, MORTAGAGE_FLAG, IMPAWN_FLAG, PLEDGE_FLAG, SELLED_FLAG, CAL_INST_TYPE,spare1,cycle_flag,repay_source_type,assure_type,own_org_code,own_org_type,currency)
    select
 CNTT_ID,CNTT_CODE,YEAR,t.ORG_CODE,a.org_name as ORG_NAME,BORROWER_ID,a.org_name as BORROWER_NAME,PROD_CODE, IS_STANDARD,LOAN_AMT,INST_RATE,APPROP_RATE,OVERDUE_RATE,USAGE,START_DATE,END_DATE,INST_PAY_TYPE,REPAY_SOURCE, SUPPLEMENT, SIGN_DATE, LOAN_TERM, INVT_CLS, INVT_SUB_CLS, TERM_CLS, USAGE_CLS, USAGE_SUB_CLS, CREDIT_FLAG, MORTAGAGE_FLAG, IMPAWN_FLAG, PLEDGE_FLAG, SELLED_FLAG, CAL_INST_TYPE,spare1,cycle_flag,repay_source_type,assure_type,own_org_code,own_org_type,'00'
   from ln_loan_cntt t,t_09_org a
   where t.cntt_code=p_cntt_code and t.org_code=a.org_code  ;
   commit;
--??????
    delete from ri_loan_rateadjust where cntt_code=p_cntt_code;
    commit;
    insert into ri_loan_rateadjust
 (RATE_ADJT_ID,     ORG_CODE,           ORG_NAME,CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,  NEW_RATE, START_DATE, ADJT_REASON, ADJT_TIME)
    select
 RATE_ADJT_ID, t.ORG_CODE, a.org_name as org_name,CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,  NEW_RATE, START_DATE, ADJT_REASON, ADJT_TIME
    from LN_RATE_ADJUST t, t_09_org a
    where  t.cntt_code=p_cntt_code and t.org_code=a.org_code ;
    commit;
 --????
    delete from ri_loan_guarantyinfo where  guaranty_grp_id=p_cntt_code;
    commit;
    insert into ri_loan_guarantyinfo
 (GUARANTY_ID, GUARANTY_GRP_ID,           WARRANTOR_ID,WARRANTOR_NAME, GUARANTY_MODE, GUARANTY_TYPE, GUARANTY_NAME, GUARANTY_VALUE, GUARANTY_RATE, GUARANTY_AMT,ASSURANCE_TERM, STORE_PLACE,FSCL_YEAR,REMARK, SPARE2, SPARE3)
    select
  GUARANTY_ID, GUARANTY_GRP_ID, SPARE1 as WARRANTOR_ID,WARRANTOR_NAME, GUARANTY_MODE, GUARANTY_TYPE, GUARANTY_NAME, GUARANTY_VALUE, GUARANTY_RATE, GUARANTY_AMT,ASSURANCE_TERM, STORE_PLACE,FSCL_YEAR, REMARK, SPARE2, SPARE3
    from ln_guaranty_desc t
    where  t.guaranty_grp_id=p_cntt_code;
    commit;
--??????
    delete from ri_loan_prinwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
    commit;
    insert into ri_loan_prinwastebook
 (PRIN_WASTE_BOOK_ID, ORG_CODE,           ORG_NAME,PROD_CODE, CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, REMARK,VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, RETURNED_FLAG,SPARE1, SPARE2,SPARE3,repay_date)
    select
  PRIN_WASTE_BOOK_ID, t.ORG_CODE, a.org_name as ORG_NAME,PROD_CODE, t.CNTT_CODE,DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, t.REMARK,VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, RETURNED_FLAG,t.SPARE1, t.SPARE2,t.SPARE3,r.REPAY_DATE
    from ln_prin_waste_book t, t_09_org a,Ln_Prvd_Exe r
    where  t.state='3' and t.cntt_code=p_cntt_code and t.org_code=a.org_code  and t.cntt_code=r.cntt_code  and (t.prod_code='10' or t.prod_code='14');
    commit;

--??????
    delete from ri_loan_prinwastebook where  cntt_code=p_cntt_code and prod_code='15';
    commit;
    insert into ri_loan_prinwastebook
 (PRIN_WASTE_BOOK_ID, ORG_CODE,           ORG_NAME,PROD_CODE, CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, repay_date)
    select
  t.prin_waste_book_id as PRIN_WASTE_BOOK_ID, t.joiner_id as org_code, a.org_name as ORG_NAME,t.PROD_CODE, t.CNTT_CODE,p.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_plan,t.SUMMERY, t.amount as CHANGE_AMT, t.record_time as RECORD_DATE,t.recorder_id as RECORDER, t.VALID_DATE, t.VOUCHER_CODE, p.DFRD_FLAG,p.AHEAD_REPAY_FLAG, p.HAND_FLAG, r.REPAY_DATE
 from ln_joiner_prin_waste_book t, t_09_org a,Ln_Prvd_Exe r,ln_prin_waste_book p
 where t.joiner_id=a.org_code and t.cntt_code=p_cntt_code and t.cntt_code=r.cntt_code and p.prin_waste_book_id=t.prin_waste_book_id and t.prod_code='15' and p.state='3';
 commit;


--??????
    delete from ri_loan_instwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
    commit;
    insert into ri_loan_instwastebook
 (    INST_WASTE_BOOK_ID, ORG_CODE,          ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG, RUSH_FLAG, RUSH_WASTE_BOOK_ID,RUSH_INST, RECORD_DATE, REMARK,HAND_FLAG, ADJUSTED_WASTE_BOOK_ID)
 select
 SELF_INST_WASTE_BOOK_ID, t.ORG_CODE,a.org_name as ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG, RUSH_FLAG, RUSH_WASTE_BOOK_ID,RUSH_INST, RECORD_DATE, t.REMARK,HAND_FLAG, ADJUSTED_WASTE_BOOK_ID
 from ln_self_inst_waste_book t, t_09_org a
 where  t.cntt_code=p_cntt_code and t.org_code=a.org_code  and (prod_code='10' or prod_code='14')
  and t.state='3' and t.summery in ('1','2');
  commit;

--??????
     delete from ri_loan_instwastebook where  cntt_code=p_cntt_code and prod_code='15';
     commit;
     insert into ri_loan_instwastebook
 (    INST_WASTE_BOOK_ID, ORG_CODE,          ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG,  RECORD_DATE, HAND_FLAG)
 select
 joiner_INST_WASTE_BOOK_ID as INST_WASTE_BOOK_ID, t.joiner_id as ORG_CODE,a.org_name as ORG_NAME,t.valid_date as BIZ_DATE,t.PROD_CODE,t.CNTT_CODE,p.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_plan,p.INST_TYPE,t.SUMMERY, t.VOUCHER_CODE,t.CAL_INST_amount, p.INST_RATE, p.INST_TERM_FROM,p.INST_TERM_TO, p.INST_TERM_FROM_FACT, p.INST_TERM_TO_FACT,t.should_receive_amount as SHOULD_RECEIVE_INST, t.already_receive_amount as ALREADY_RECEIVE_INST,t.RECEIVE_INST_amount,p.AHEAD_REPAY_FLAG,  t.record_time as RECORD_DATE, p.HAND_FLAG
 from ln_joiner_inst_waste_book t, t_09_org a,ln_self_inst_waste_book p
 where t.cntt_code=p_cntt_code and t.joiner_id=a.org_code and t.prod_code='15' and t.inst_waste_book_id=p.self_inst_waste_book_id
  and p.state='3' and p.summery in ('1','2');
  commit;

 --????
      delete from ri_loan_dfrdcntt where cntt_code =p_cntt_code ;
      commit;
      insert into ri_loan_dfrdcntt
(DFRD_CNTT_ID, DFRD_CNTT_CODE, YEAR,CNTT_CODE, PRVD_INFM_CODE,PRE_REPAY_EXE_CODE, PROD_CODE, ORG_CODE,TO_DATE_AMT, DFRD_AMT, DFRD_RATE,DFRD_REASON, SIGN_DATE, PROVINCE,CITY, IS_STANDARD, SUPPLEMENT,CNTT_MGR, OPER_TIME, START_DATE, END_DATE, DFRD_TERM)
select
 DFRD_CNTT_ID, DFRD_CNTT_CODE, YEAR,CNTT_CODE, PRVD_INFM_CODE,PRE_REPAY_EXE_CODE, PROD_CODE, ORG_CODE,TO_DATE_AMT, DFRD_AMT, DFRD_RATE,DFRD_REASON, SIGN_DATE, PROVINCE,CITY, IS_STANDARD, SUPPLEMENT,CNTT_MGR, OPER_TIME, START_DATE, END_DATE, DFRD_TERM
from LN_DFRD_CNTT
where cntt_code =p_cntt_code ;
commit;
--????
      delete from ri_loan_repayplan where cntt_code =p_cntt_code ;
      commit;
      insert into ri_loan_repayplan
(REPAY_EXE_CODE, PRVD_EXE_PLAN_CODE, PRE_REPAY_EXE_CODE,CNTT_CODE, PRVD_INFM_CODE, REPAY_DATE,REPAY_AMT, AT_TERM_STATE, SPARE1,SPARE2)
select
 REPAY_EXE_CODE, PRVD_EXE_PLAN_CODE, PRE_REPAY_EXE_CODE,CNTT_CODE, PRVD_INFM_CODE, REPAY_DATE,REPAY_AMT, AT_TERM_STATE, SPARE1,SPARE2
from Ln_Repay_Plan
where cntt_code =p_cntt_code ;
commit;

--????
      delete from ri_loan_prvdexe where cntt_code =p_cntt_code ;
      commit;
      insert into ri_loan_prvdexe
(PRVD_EXE_CODE, CNTT_CODE, PRVD_DATE, PRVD_AMT, FINAL_REPAY_DATE, SPARE1, SPARE2)
select
 PRVD_EXE_CODE, CNTT_CODE, PRVD_DATE, PRVD_AMT, REPAY_DATE, SPARE1, SPARE2
from Ln_Prvd_Exe
where cntt_code =p_cntt_code ;
commit;

  end loop;
  close normal_rs;

end ri_loan_init_byOrg;
--20100115 update
/

