CREATE VIEW RI_VIEW_LOAN_STRUCT AS
  select c.cust_type1,
       c.cust_type2,
       c.cust_type3,
       decode(b.cycle_flag, '1', 'cycle', b.loan_term) loan_term,
       b.invt_cls,
       nvl((select CREDIT_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           b.CREDIT_FLAG) as CREDIT_FLAG,
       nvl((select MORTAGAGE_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           b.MORTAGAGE_FLAG) as MORTAGAGE_FLAG,
       nvl((select IMPAWN_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           b.IMPAWN_FLAG) as IMPAWN_FLAG,
       nvl((select PLEDGE_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           b.PLEDGE_FLAG) as PLEDGE_FLAG,
       a.sort_id,
       a.cntt_code,
       a.cntt_balance,
       a.acct_period,
       a.cntt_org_code,
       d.pre_balance,
       e.year_sum_prvd_amt,
       f.inst_bal
  from ri_assetresult       a,
       ri_loan_baseinfo     b,
       ri_custbaseinfo      c,
       ri_asset_presort     d,
       ri_loan_sum          e,
       ri_loan_inst_overdue f
 where a.cntt_code = b.cntt_code
   and b.borrower_id = c.cust_id
   and a.cntt_code = d.cntt_code(+)
   and a.acct_period = d.acct_period(+)
   and a.cntt_code = e.cntt_code(+)
   and a.acct_period = e.acct_period(+)
   and a.cntt_code = f.cntt_code(+)
   and a.acct_period = f.acct_period(+)
/

