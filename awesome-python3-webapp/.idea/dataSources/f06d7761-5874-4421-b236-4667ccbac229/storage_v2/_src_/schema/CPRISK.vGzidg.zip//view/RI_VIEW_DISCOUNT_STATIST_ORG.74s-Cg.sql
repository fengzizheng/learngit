CREATE VIEW RI_VIEW_DISCOUNT_STATIST_ORG AS
  select w1."ACCT_PERIOD",w1."CNTT_ORG_CODE",w1."NUM",w1."CNTT_BALANCE",w1."YEAR_SUM_PRVD_AMT",w1."PERIOD_SUM_PRVD_AMT",w1."PERIOD_SUM_REPY_AMT",w1."PERIOD_SUM_DFRD_AMT",w1."INST_BAL",w2.pre_balance from
(
select acct_period,cntt_org_code, count(*) num,sum(cntt_balance) cntt_balance ,sum(year_sum_prvd_amt) year_sum_prvd_amt,sum(period_sum_prvd_amt) period_sum_prvd_amt,sum(period_sum_repy_amt) period_sum_repy_amt, 0 period_sum_dfrd_amt,sum(inst_bal) inst_bal
from (
select a.acct_period,a.asset_org cntt_org_code, a.asset_balance cntt_balance,
0 year_sum_prvd_amt,
0 period_sum_prvd_amt,
0 period_sum_repy_amt,
0 inst_bal
from ri_otherasset_result a
where a.asset_type='10006'
) group by acct_period,cntt_org_code
) w1,
(
select t1.asset_type,t1.asset_org,t1.acct_period,t1.pre_period,t2.asset_balance pre_balance
from (
select a.asset_type,a.asset_org,a.acct_period, a.asset_balance,
(select max(acct_period) from RI_VIEW_CREDIT_SUM where acct_period<a.acct_period and asset_type=a.asset_type and asset_org=a.asset_org ) pre_period
from RI_VIEW_CREDIT_SUM a where a.asset_type='10006') t1,RI_VIEW_CREDIT_SUM t2
where t1.asset_type=t2.asset_type(+) and t1.asset_org=t2.asset_org(+) and t1.pre_period=t2.acct_period(+)
)w2
where w1.acct_period=w2.acct_period(+) and w1.cntt_org_code=w2.asset_org(+)
/

