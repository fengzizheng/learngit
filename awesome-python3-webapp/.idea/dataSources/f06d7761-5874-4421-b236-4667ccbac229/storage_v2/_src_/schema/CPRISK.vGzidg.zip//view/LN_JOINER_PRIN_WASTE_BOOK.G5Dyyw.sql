CREATE VIEW LN_JOINER_PRIN_WASTE_BOOK AS
  SELECT JOINER_INST_WASTE_BOOK_ID prin_waste_book_id, --  参与者利息台账主键
       VALID_DATE, --  生效日期
       (CASE WHEN A.PROD_CODE IN('001016002','001016','001016001') THEN '15'
 WHEN A.PROD_CODE IN ('001001','001001001','001001002','001001003','001001004','001002','001002001','001002002','001002003') THEN '10'
 WHEN A.PROD_CODE IN('002002001','001018') THEN '11' ELSE A.PROD_CODE END) PROD_CODE, -- 贷款品种编码
       CNTT_CODE, -- 合同编码
       PRVD_INFM_CODE, -- 放款通知单编号
       REPAY_EXE_PLAN, -- 还款执行计划编号
       INST_WASTE_BOOK_ID, --利息台账ID
       JOINER_ID, -- 参与者ID
       JOINER_NAME, -- JOINER_NAME
       CAL_INST_AMOUNT amount, -- 计息金额
       SHOULD_RECEIVE_AMOUNT, -- 应收利息金额
       ALREADY_RECEIVE_AMOUNT, -- 已收利息金额
       RECEIVE_INST_AMOUNT, --  收到利息金额
       VOUCHER_CODE, -- 凭证编码
       RETURNED_AMOUNT, -- 已划回金额
       SUMMERY, -- 摘要
       RUSH_FLAG, -- 冲减标志
       RUSH_WASTE_BOOK_ID, -- 冲减利息台账ID
       RUSH_AMOUNT, --冲减金额
       RECORDER_ID, -- 录入人ID
       RECORD_TIME, -- 录入时间
       CHECKER_ID, --  复核人
       CHECK_TIME, --复核时间
       b.syn_cust_id AS IS_org,
       STATE --状态
       FROM(
SELECT A.ACCOUNTID JOINER_INST_WASTE_BOOK_ID, --  参与者利息台账主键
       (SELECT ACCOUNTCREDATE
          FROM ACCOU_PUB_INFO
         WHERE ACCOUNTID = A.ACCOUNTID) VALID_DATE, --  生效日期
       B.BUSITYPE PROD_CODE, --  业务品种号
       '' CNTT_CODE, -- 合同编码
       C.LOANDUEBILLNO PRVD_INFM_CODE, -- 放款通知单编号
       '' REPAY_EXE_PLAN, -- 还款执行计划编号
       A.ACCOUNTID INST_WASTE_BOOK_ID, --利息台账ID
       b.suborg JOINER_ID, -- 参与者ID
       '' JOINER_NAME, -- JOINER_NAME
       A.INTERACCO CAL_INST_AMOUNT, -- 计息金额
       '' SHOULD_RECEIVE_AMOUNT, -- 应收利息金额
       A.INTEREST ALREADY_RECEIVE_AMOUNT, -- 已收利息金额
       '' RECEIVE_INST_AMOUNT, --  收到利息金额
       '' VOUCHER_CODE, -- 凭证编码
       '' RETURNED_AMOUNT, -- 已划回金额
       decode(c.ABSTRACT,0,1,1,2,c.abstract) SUMMERY, -- 摘要
       '' RUSH_FLAG, -- 冲减标志
       '' RUSH_WASTE_BOOK_ID, -- 冲减利息台账ID
       '' RUSH_AMOUNT, --冲减金额
       '' RECORDER_ID, -- 录入人ID
       '' RECORD_TIME, -- 录入时间
       '' CHECKER_ID, --  复核人
       '' CHECK_TIME, --复核时间
       '3' STATE, --状态
       a.LOANDUEBILLNO
  FROM CREINTER_ACCO_INFO A, CRECAP_INTERBASE_INFO B, CRECAP_ACCO_INFO C
 WHERE A.ACCOUNTID = B.ACCOUNTID
   AND A.ACCOUNTID = C.ACCOUNTID
   AND b.BUSITYPE IN('001016002','001016','001016001'))A,
   BUSI_DUEBILL B
   WHERE A.LOANDUEBILLNO=B.DUEBILLNO(+)
  -- AND b.syn_cust_id =''  ---这里还没有确定，这里中电财会给一个特殊的编号区分出中电财数据
/

