CREATE procedure ri_leasebalance_cal(p_cntt_code  in varchar2,
                                               p_period   in varchar2,p_result out varchar2) is
  p_prin_balance fin_tenancy_cntt.cntt_cost%type; --本金余额
  p_lease_balance fin_tenancy_cntt.cntt_cost%type;--租金余额
  p_inst_balance fin_tenancy_cntt.cntt_cost%type; --利息余额
  p_loan_cost  fin_tenancy_cntt.cntt_cost%type;   --合同成本
  i_loan_cost   fin_tenancy_cntt.cntt_cost%type;
  i_return_cost  fin_tenancy_cntt.cntt_cost%type;
  i_receive_cost fin_tenancy_cntt.cntt_cost%type;

  i_cntt_inst fin_tenancy_cntt.cntt_cost%type; --初始利息金额
  i_return_inst  fin_tenancy_cntt.cntt_cost%type; --正常收取利息金额
  i_change_inst  fin_tenancy_cntt.cntt_cost%type; --变更利息金额
  i_org  fin_tenancy_cntt.cntt_service_org%type;
  num integer;

begin
  --前提：针对所有已经起租的融资租赁合同计算其每月末的余额情况
  --本金余额计算
   select nvl(device_balance,0) into i_loan_cost
   from fin_tenancy_cntt where rent_cntt_code=p_cntt_code;
  --提前退租本金
   select nvl(sum(t1.return_rent_prin),0) into i_return_cost
   from FIN_TENANCY_AHEAD_RETURN_RENT t1 where t1.rent_cntt_code = p_cntt_code
   and t1.state =9
   --and subStr(t1.BAL_CHECK_TIME,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd');
   and (t1.BAL_CHECK_TIME is null or subStr(t1.BAL_CHECK_TIME,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));
--计算合同成本（减去已提前退租的）
   select i_loan_cost-i_return_cost into p_loan_cost from dual;
  --首先判断该合同是否结清
  select count(1) into num
  from fin_tenancy_cntt where rent_cntt_code=p_cntt_code
  and state='6';
  --未结清
  if num=0 then
         --正常收取的本金
         select nvl(sum(t2.should_receive_amt),0) into i_receive_cost
         from FIN_TENANCY_RENT_INCOME t2 where t2.rent_cntt_code=p_cntt_code
         and t2.state =9
         and (should_receive_date<'2011-01-01' or subStr(t2.bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));
--计算本金余额
         select i_loan_cost-i_return_cost-i_receive_cost into p_prin_balance from dual;

         --租金余额计算
           --查询初始利息总额
         select nvl(cntt_rent,0)-nvl(device_balance,0) into i_cntt_inst
         from fin_tenancy_cntt where rent_cntt_code=p_cntt_code;
          --判断合同所属机构
         select cntt_applicant_org into i_org
         from fin_tenancy_cntt  where rent_cntt_code = p_cntt_code;
         if i_org='1099' then
             --查询2011年10月31日的利息余额
             select count(cntt_code) into num
             from ri_otherasset_lease a,ri_otherasset_rptinfo b where
             a.rpt_id=b.rpt_id
             and b.rpt_type='10004' and b.import_flag is null and b.rpt_date like '2011-10-%'
             and b.rpt_org='1099'
             and cntt_code=p_cntt_code;
             --有历史数据可查，则按照历史数据作为初始数据计算利息
             if num=1 then
                 select a.balance_inst into i_cntt_inst
                 from ri_otherasset_lease a,ri_otherasset_rptinfo b where
                 a.rpt_id=b.rpt_id
                 and b.rpt_type='10004' and b.import_flag is null and b.rpt_date like '2011-10-%'
                 and b.rpt_org='1099'
                 and cntt_code=p_cntt_code;
                  --正常收取的利息
                 select nvl(sum(t2.should_receive_inst_amt),0) into i_return_inst
                 from FIN_TENANCY_RENT_INCOME t2 where t2.rent_cntt_code=p_cntt_code
                 and t2.state =9
                 and (should_receive_date>='2011-11-01' and subStr(t2.bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));
                 --查询变更引起的利息变化
                 select nvl(sum(new_amt-old_amt),0) into i_change_inst from fin_tenancy_amt_change where state=9
                 and cntt_code=p_cntt_code
                 and (bal_check_time>='2011-11-01' and subStr(bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));

             --新发生合同
             else
                  --正常收取的利息
                 select nvl(sum(t2.should_receive_inst_amt),0) into i_return_inst
                 from FIN_TENANCY_RENT_INCOME t2 where t2.rent_cntt_code=p_cntt_code
                 and t2.state ='9'
                 and (should_receive_date<'2011-01-01' or subStr(t2.bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));
                 --查询变更引起的利息变化
                 select nvl(sum(new_amt-old_amt),0) into i_change_inst from fin_tenancy_amt_change where state=9
                 and cntt_code=p_cntt_code
                 and subStr(bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd');

             end if;
         else
              --查询2010年12月31日的利息余额
             select count(cntt_code) into num
             from ri_otherasset_lease a,ri_otherasset_rptinfo b where
             a.rpt_id=b.rpt_id
             and b.rpt_type='10004' and b.import_flag is null and b.rpt_date like '2010-12-%'
             and b.rpt_org<>'1099'
             and cntt_code=p_cntt_code;
             --有历史数据可查，则按照历史数据作为初始数据计算利息
             if num=1 then
                 select a.balance_inst into i_cntt_inst
                 from ri_otherasset_lease a,ri_otherasset_rptinfo b where
                 a.rpt_id=b.rpt_id
                 and b.rpt_type='10004' and b.import_flag is null and b.rpt_date like '2010-12-%'
                 and b.rpt_org<>'1099'
                 and cntt_code=p_cntt_code;
                  --正常收取的利息
                 select nvl(sum(t2.should_receive_inst_amt),0) into i_return_inst
                 from FIN_TENANCY_RENT_INCOME t2 where t2.rent_cntt_code=p_cntt_code
                 and t2.state ='9'
                 and (should_receive_date>='2011-01-01' and subStr(t2.bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));
                 --查询变更引起的利息变化
                 select nvl(sum(new_amt-old_amt),0) into i_change_inst from fin_tenancy_amt_change where state=9
                 and cntt_code=p_cntt_code
                 and (bal_check_time>='2011-01-01' and subStr(bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));

             --新发生合同
             else
                  --正常收取的利息
                 select nvl(sum(t2.should_receive_inst_amt),0) into i_return_inst
                 from FIN_TENANCY_RENT_INCOME t2 where t2.rent_cntt_code=p_cntt_code
                 and t2.state ='9'
                 and (should_receive_date<'2011-01-01' or subStr(t2.bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd'));
                 --查询变更引起的利息变化
                 select nvl(sum(new_amt-old_amt),0) into i_change_inst from fin_tenancy_amt_change where state=9
                 and cntt_code=p_cntt_code
                 and subStr(bal_check_time,0,10)<=to_char(last_day(to_date(p_period, 'yyyy-MM-dd')), 'yyyy-MM-dd');

             end if;
          end if;

 --计算利息余额
         p_inst_balance:=i_cntt_inst+i_change_inst-i_return_inst;
--计算租金余额
         p_lease_balance:=p_prin_balance+p_inst_balance;
--结清
   else
         p_prin_balance:=0;
         p_inst_balance:=0;
         p_lease_balance:=0;
   end if;
   --构造返回结果
   p_result:=p_loan_cost||';'||p_lease_balance||';'||p_prin_balance||';'||p_inst_balance||';';
/*异常处理*/
exception
  when others then
    raise;

end ri_leasebalance_cal;
--2012-02-06
/

