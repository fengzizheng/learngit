CREATE VIEW RI_VIEW_PAPER_PRINTINFO AS
  select distinct a.rpt_id,a.asset_id,a.state,c.type,a.asset_org,a.acct_period,a.paper_type,a.asset_item,a.asset_item_sort,a.book_value,a.market_value,a.profit_loss,
c.sort,c.sort_value,c.remark,
(select org_name from ri_org_info where org_code=c.oper_org) as oper_org_name,
c.operator_id,
(select person_name from au_employee where id=c.operator_id) as operator,
c.oper_time,
c.report_person,
(select person_name from au_employee where id=c.report_person) as reportor,
c.report_time
from ri_otherasset_paper_result a,ri_otherasset_paper_sortdetail c
where  a.asset_id=c.asset_id and a.state>=c.type
/

