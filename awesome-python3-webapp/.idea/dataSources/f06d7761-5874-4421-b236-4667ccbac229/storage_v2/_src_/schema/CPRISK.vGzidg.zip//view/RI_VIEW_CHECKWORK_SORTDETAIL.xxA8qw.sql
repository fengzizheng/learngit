CREATE VIEW RI_VIEW_CHECKWORK_SORTDETAIL AS
  select '信贷类资产' as type,1 as no_id,'20001' asset_type,'自营贷款' as sub_type,'' as sub_type_2,a.cntt_code asset_id, a.cntt_balance asset_balance,b.sort, a.acct_period,a.cntt_org_code asset_org,
--SUBSTR ( a.cntt_org_code, 0, 2 ) as parent_code,
c.parent_code,
c.org_name,a.state,b.type as sort_type,
decode(b.sort,1,a.cntt_balance,'') as sort_1,
decode(b.sort,2,a.cntt_balance,'') as sort_2,
decode(b.sort,3,a.cntt_balance,'') as sort_3,
decode(b.sort,4,a.cntt_balance,'') as sort_4,
decode(b.sort,5,a.cntt_balance,'') as sort_5
from ri_assetresult a,ri_assetsortdetail b,ri_org_info c
where a.cntt_org_code=c.ORG_CODE and a.sort_id=b.sort_id and a.state>=b.type
union
select '信贷类资产' as type,1 as no_id,'20008' asset_type,'保理' as sub_type,'' as sub_type_2,a.cntt_code asset_id, a.cntt_balance asset_balance,b.sort, a.acct_period,a.cntt_org_code asset_org,
--SUBSTR ( a.cntt_org_code, 0, 2 ) as parent_code,
c.parent_code,
c.org_name,a.state,b.type as sort_type,
decode(a.sort,1,a.cntt_balance,2,a.cntt_balance,3,a.cntt_balance,'') as sort_1,
decode(a.sort,4,a.cntt_balance,5,a.cntt_balance,6,a.cntt_balance,'') as sort_2,
decode(a.sort,7,a.cntt_balance,8,a.cntt_balance,'') as sort_3,
decode(a.sort,9,a.cntt_balance,'') as sort_4,
decode(a.sort,10,a.cntt_balance,'') as sort_5
from RI_FACTORASSETRESULT a,RI_FACTORASSETSORTDETAIL b,ri_org_info c
where a.cntt_org_code=c.ORG_CODE and a.sort_id=b.sort_id and a.state>=b.type
union
select '股权投资资产' type,4 as no_id,'20006' asset_type,c.stock_type as sub_type,'' as sub_type_2,a.asset_id, d.asset_balance,d.sort,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code,
b.org_name,a.state,d.type as sort_type,
decode(d.sort,1,d.asset_balance,'') as sort_1,
decode(d.sort,2,d.asset_balance,'') as sort_2,
decode(d.sort,3,d.asset_balance,'') as sort_3,
decode(d.sort,4,d.asset_balance,'') as sort_4,
decode(d.sort,5,d.asset_balance,'') as sort_5
from ri_otherasset_result a,ri_otherasset_sortdetail d,ri_org_info b,ri_otherasset_stock c
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.rpt_id=c.rpt_id and asset_type='10001'
and a.result_id=d.result_id and a.state>=d.type
union
select '同业债权资产' type,2 as no_id,'20004' asset_type,c.creditright_type as sub_type,'' as sub_type_2,a.asset_id, d.asset_balance,d.sort,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code,
b.org_name,a.state,d.type as sort_type,
decode(d.sort,1,d.asset_balance,'') as sort_1,
decode(d.sort,2,d.asset_balance,'') as sort_2,
decode(d.sort,3,d.asset_balance,'') as sort_3,
decode(d.sort,4,d.asset_balance,'') as sort_4,
decode(d.sort,5,d.asset_balance,'') as sort_5
from ri_otherasset_result a,ri_org_info b,ri_otherasset_creditright c,ri_otherasset_sortdetail d
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.rpt_id=c.rpt_id and asset_type='10003'
and a.result_id=d.result_id and a.state>=d.type
union
select '信贷类资产' as type,1 as no_id,'20002' asset_type,'融资租赁' as sub_type,'' as sub_type_2,a.asset_id, d.asset_balance,d.sort,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code,
b.org_name,a.state,d.type as sort_type,
decode(d.sort,1,d.asset_balance,'') as sort_1,
decode(d.sort,2,d.asset_balance,'') as sort_2,
decode(d.sort,3,d.asset_balance,'') as sort_3,
decode(d.sort,4,d.asset_balance,'') as sort_4,
decode(d.sort,5,d.asset_balance,'') as sort_5
from ri_otherasset_result a,ri_org_info b,ri_otherasset_sortdetail d
where a.asset_org=b.ORG_CODE and asset_type ='10004'
and a.result_id=d.result_id and a.state>=d.type
union
select '信贷类资产' as type,1 as no_id,'20003' asset_type,'票据贴现' as sub_type,'' as sub_type_2,a.asset_id, d.asset_balance,d.sort,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code,
b.org_name,a.state,d.type as sort_type,
decode(d.sort,1,d.asset_balance,'') as sort_1,
decode(d.sort,2,d.asset_balance,'') as sort_2,
decode(d.sort,3,d.asset_balance,'') as sort_3,
decode(d.sort,4,d.asset_balance,'') as sort_4,
decode(d.sort,5,d.asset_balance,'') as sort_5
from ri_otherasset_result a,ri_org_info b,ri_otherasset_sortdetail d
where a.asset_org=b.ORG_CODE and asset_type ='10006'
and a.result_id=d.result_id and a.state>=d.type
union
select  '其他类资产' as type,5 as no_id,'20007' asset_type,c.other_type as sub_type,c.other_type_2 as sub_type_2,a.asset_id, d.asset_balance,d.sort,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code,
b.org_name,a.state,d.type as sort_type,
decode(d.sort,1,d.asset_balance,'') as sort_1,
decode(d.sort,2,d.asset_balance,'') as sort_2,
decode(d.sort,3,d.asset_balance,'') as sort_3,
decode(d.sort,4,d.asset_balance,'') as sort_4,
decode(d.sort,5,d.asset_balance,'') as sort_5
from ri_otherasset_result a,ri_org_info b,ri_otherasset_other c,ri_otherasset_sortdetail d
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.rpt_id=c.rpt_id and asset_type='10005'
and a.result_id=d.result_id and a.state>=d.type
union
select '证券投资类资产' as type,3 as no_id,'20005' as asset_type,r.paper_type as sub_type,'' as sub_type_2,r.asset_id,r.asset_balance,0 sort,r.acct_period,r.asset_org,
r.parent_code,r.org_name,r.state,r.sort_type,
(select sort_value from ri_otherasset_paper_sortdetail  where  sort=1 and asset_id=r.asset_id and type=r.sort_type ) as sort_1,
(select sort_value from ri_otherasset_paper_sortdetail  where  sort=2 and asset_id=r.asset_id and type=r.sort_type ) as sort_2,
(select sort_value from ri_otherasset_paper_sortdetail  where  sort=3 and asset_id=r.asset_id and type=r.sort_type ) as sort_3,
(select sort_value from ri_otherasset_paper_sortdetail  where  sort=4 and asset_id=r.asset_id and type=r.sort_type ) as sort_4,
(select sort_value from ri_otherasset_paper_sortdetail  where  sort=5 and asset_id=r.asset_id and type=r.sort_type ) as sort_5
from (
select distinct a.rpt_id,a.asset_id,a.paper_type,a.book_value as asset_balance,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code,
b.org_name,a.state,a.remark,a.acct_period,d.type as sort_type
from ri_otherasset_paper_result a,ri_org_info b,ri_otherasset_paper_sortdetail d
where a.asset_org=b.ORG_CODE
and a.result_id=d.result_id and a.state>=d.type
) r
/

