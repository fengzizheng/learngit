CREATE VIEW RI_VIEW_FACTOR_FENLEI AS
  select a.sort_id,
       a.cntt_code asset_id,
       a.acct_period,
       a.sort,
       --a.sort_desc,
       b.sort_desc,
       --a.remark,
       b.remark,
       b.type,
       (select person_name from au_employee where id=b.operator_id) as operator,
       b.oper_time as oper_time,
      (select person_name from au_employee where id=b.report_person) as reportor,
       b.report_time as report_time
  from RI_FACTORASSETRESULT a, RI_FACTORASSETSORTDETAIL b
  where a.sort_id=b.sort_id
/

