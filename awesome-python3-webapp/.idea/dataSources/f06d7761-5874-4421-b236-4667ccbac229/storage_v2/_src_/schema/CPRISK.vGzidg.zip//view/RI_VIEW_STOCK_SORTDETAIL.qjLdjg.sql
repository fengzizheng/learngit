CREATE VIEW RI_VIEW_STOCK_SORTDETAIL AS
  select c.detail_id,c.type,a.result_id,a.rpt_id,a.asset_id, d.stock_TYPE,d.project_name, a.acct_period,a.asset_org,b.org_name,d.BALANCE as import_balance,c.asset_balance,a.state,c.sort,c.sort_desc,c.remark,
decode(c.sort,5011,c.asset_balance,'') as sort_1,
decode(c.sort,5012,c.asset_balance,'') as sort_2,
decode(c.sort,5013,c.asset_balance,'') as sort_3,
decode(c.sort,5014,c.asset_balance,'') as sort_4,
decode(c.sort,5015,c.asset_balance,'') as sort_5,
(SELECT e.sort_desc
            FROM ri_otherasset_result e
           WHERE e.asset_id = a.asset_id and e.asset_org=a.asset_org
           and e.acct_period in(select max(acct_period) from ri_otherasset_result where asset_id = a.asset_id and asset_org=a.asset_org and acct_period<a.acct_period)
         ) AS pre_sort,
(select sum(c.asset_balance) from RI_OTHERASSET_SORTDETAIL
where sort in ('5013','5014','5015')
and detail_id=c.detail_id ) as abnormal_balance
from ri_otherasset_result a,ri_org_info b,RI_OTHERASSET_SORTDETAIL c,RI_OTHERASSET_STOCK d
where a.asset_org=b.ORG_CODE
and a.ASSET_TYPE='10001'
and a.asset_id=d.asset_id and a.rpt_id=d.rpt_id
and a.result_id=c.result_id and a.state>=c.type
/

