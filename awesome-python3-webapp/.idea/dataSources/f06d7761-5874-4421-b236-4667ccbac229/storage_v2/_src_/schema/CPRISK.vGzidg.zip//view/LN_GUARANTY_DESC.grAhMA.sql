CREATE VIEW LN_GUARANTY_DESC AS
  SELECT A.ACCOUNTID GUARANTY_ID, --  担保情况编号
       A.GUARANTYID GUARANTY_GRP_ID, --  担保组编号（与合同号关联）
       A.MORPLEID WARRANTOR_ID, --  担保人编号
       A.MORTPLENAME WARRANTOR_NAME, --  担保人名称
       '抵押质押' GUARANTY_MODE, --  担保类型
       A.MORTPLEAMT GUARANTY_AMT, -- 担保金额
       A.MORTPLETYPE GUARANTY_TYPE, --  保证类别 /抵押类型/质押类型
       '' GUARANTY_NAME, -- 抵/质押物名称
       A.ESTIVAL GUARANTY_VALUE, -- 评估价值
       A.MORTPLERATE GUARANTY_RATE, -- 抵/质押率
       '' ASSURANCE_TERM, -- 保险期限
       '' STORE_PLACE, -- 存放地点
       '' FSCL_YEAR, -- 会计年度
       '' REMARK, -- 备注
       '' SPARE1, -- 客户id
       '' SPARE2, -- 备用2
       '' SPARE3, -- 备用3
       '' APPLY_AMT, -- 对应申请金额
       '' INST, -- 对应利息及其它
       '' TOTAL_INST, --总利息及其它
       '' INCLUDE_INST_FLAG, -- 是否包含利息
       '' GUARANTY_RATE_INCLUDE_INST, -- 抵押率（含息）
       '' LOAN_BAL, -- 贷款余额
       '' GUARANTY_FOREIGN_BAL, -- 对外担保余额
       '' IMPAWN_RATE --质押率
  FROM MORTPLE_INTERBASE_INFO A --抵押质押
UNION
--保证金
SELECT A.ACCOUNTID GUARANTY_ID, --  担保情况编号
       A.maincontractid GUARANTY_GRP_ID, --  担保组编号（与合同号关联）
       A.Cusid WARRANTOR_ID, --  担保人编号
       A.Cuschiname WARRANTOR_NAME, --  担保人名称
       '保证金' GUARANTY_MODE, --  担保类型
       A.Bailsum GUARANTY_AMT, -- 担保金额
       '' GUARANTY_TYPE, --  保证类别 /抵押类型/质押类型
       '' GUARANTY_NAME, -- 抵/质押物名称
       '' GUARANTY_VALUE, -- 评估价值
       '' GUARANTY_RATE, -- 抵/质押率
       '' ASSURANCE_TERM, -- 保险期限
       '' STORE_PLACE, -- 存放地点
       '' FSCL_YEAR, -- 会计年度
       '' REMARK, -- 备注
       '' SPARE1, -- 客户id
       '' SPARE2, -- 备用2
       '' SPARE3, -- 备用3
       '' APPLY_AMT, -- 对应申请金额
       '' INST, -- 对应利息及其它
       '' TOTAL_INST, --总利息及其它
       '' INCLUDE_INST_FLAG, -- 是否包含利息
       '' GUARANTY_RATE_INCLUDE_INST, -- 抵押率（含息）
       '' LOAN_BAL, -- 贷款余额
       '' GUARANTY_FOREIGN_BAL, -- 对外担保余额
       '' IMPAWN_RATE --质押率
  FROM guaramt_interbase_Info A --抵押质押
UNION
--担保
SELECT A.ACCOUNTID GUARANTY_ID, --  担保情况编号
       A.guarantyid, --  担保组编号（与合同号关联）
       b.Cusid WARRANTOR_ID, --  担保人编号
       b.Cuschiname WARRANTOR_NAME, --  担保人名称
       '担保' GUARANTY_MODE, --  担保类型
       A. guaramount, -- 担保金额
       A.guarway GUARANTY_TYPE, --  保证类别 /抵押类型/质押类型
       '' GUARANTY_NAME, -- 抵/质押物名称
       '' GUARANTY_VALUE, -- 评估价值
       '' GUARANTY_RATE, -- 抵/质押率
       '' ASSURANCE_TERM, -- 保险期限
       '' STORE_PLACE, -- 存放地点
       '' FSCL_YEAR, -- 会计年度
       '' REMARK, -- 备注
       '' SPARE1, -- 客户id
       '' SPARE2, -- 备用2
       '' SPARE3, -- 备用3
       '' APPLY_AMT, -- 对应申请金额
       '' INST, -- 对应利息及其它
       '' TOTAL_INST, --总利息及其它
       '' INCLUDE_INST_FLAG, -- 是否包含利息
       '' GUARANTY_RATE_INCLUDE_INST, -- 抵押率（含息）
       '' LOAN_BAL, -- 贷款余额
       '' GUARANTY_FOREIGN_BAL, -- 对外担保余额
       '' IMPAWN_RATE --质押率
  FROM guar_condInfo a,
       guarcus_baseInfo b
   WHERE a.accountid=b.accountid
/

