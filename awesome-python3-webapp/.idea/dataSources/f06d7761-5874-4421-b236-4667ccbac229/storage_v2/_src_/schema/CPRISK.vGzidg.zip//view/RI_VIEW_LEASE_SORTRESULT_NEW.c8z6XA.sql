CREATE VIEW RI_VIEW_LEASE_SORTRESULT_NEW AS
  select c.cust_id,
       c.name,
       c.cust_type1,
       c.cust_type1_desc,
       c.cust_type2,
       c.cust_type2_desc,
       d.period loan_term,
       '33' term_cls,
       d.invt_cls,
       '' term_desc,--(SELECT NAME FROM syn_ln_loan_stat_cls where LOAN_STAT_CLS_ID = d.FUND_DIRECTION)
       '42' usage_cls,
       '' usage_cls_desc, --(SELECT NAME FROM syn_ln_loan_stat_cls where LOAN_STAT_CLS_ID = d.usage_cls)
       '423' usage_sub_cls,
       '' usage_sub_desc,--(SELECT NAME FROM syn_ln_loan_stat_cls where LOAN_STAT_CLS_ID = d.usage_sub_cls)
       d.CREDIT_FLAG,
       d.MORTAGAGE_FLAG,
       d.IMPAWN_FLAG,
       d.PLEDGE_FLAG,
       a.result_id sort_id,
       a.asset_id cntt_code,
       a.asset_balance,
       a.asset_balance cntt_balance,
       --f.inst_bal,
       a.acct_period,
       a.asset_org cntt_org_code,
       a.asset_org,
       b.parent_code, --SUBSTR(a.asset_org, 0, 2)
       b.org_name,
       a.state,
       a.sort,
       a.sort_desc,
       a.remark,
       decode(a.sort, 5011, a.asset_balance, '') as sort_1,
       decode(a.sort, 5012, a.asset_balance, '') as sort_2,
       decode(a.sort, 5013, a.asset_balance, '') as sort_3,
       decode(a.sort, 5014, a.asset_balance, '') as sort_4,
       decode(a.sort, 5015, a.asset_balance, '') as sort_5,
       '' pre_sort,
       (select sum(asset_balance)
          from ri_otherasset_result
         where sort in ('5013','5014','5015')
           and result_id = a.result_id) as abnormal_balance,
       d.leasehold_type   -- add by YiDehong
  from ri_otherasset_result   a,
       ri_org_info      b,
       ri_custbaseinfo  c,
       RI_VIEW_LEASE_info_new d  -- edit by YiDehong replace RI_VIEW_LEASE_info to RI_VIEW_LEASE_info_new
       --ri_asset_presort e,
       --ri_loan_inst_overdue f
 where a.asset_org = b.ORG_CODE
   and a.asset_type='10004'
   and a.asset_id = d.cntt_code and a.acct_period=d.acct_period
   and d.cust_id = c.cust_id(+)
/

