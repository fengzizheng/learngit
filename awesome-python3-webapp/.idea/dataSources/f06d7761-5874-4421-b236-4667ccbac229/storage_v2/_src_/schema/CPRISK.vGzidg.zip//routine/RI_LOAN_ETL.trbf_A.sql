CREATE procedure ri_loan_etl(p_date in varchar2) is
 begin
--ri_loan_etl_lease(p_date);
ri_loan_etl_self(p_date);


DELETE FROM SYN_LN_LOAN_CNTT;
COMMIT;
INSERT INTO SYN_LN_LOAN_CNTT
SELECT  
cntt_code AS CNTT_ID   ,--待定
CNTT_CODE               ,
YEAR                    ,
ORG_CODE                ,
OWN_ORG_CODE            ,
OWN_ORG_TYPE            ,
APLY_CODE               ,
BORROWER_ID             ,
PROD_CODE               ,
IS_STANDARD             ,
LOAN_AMT                ,
INST_RATE               ,
APPROP_RATE             ,
OVERDUE_RATE            ,
USAGE                   ,
START_DATE              ,
END_DATE                ,
INST_PAY_TYPE           ,
REPAY_SOURCE            ,
SUPPLEMENT              ,
SIGN_DATE               ,
PROVINCE                ,
CITY                    ,
LOAN_TERM               ,
STATE                   ,
INVT_CLS                ,
INVT_SUB_CLS            ,
TERM_CLS                ,
USAGE_CLS               ,
USAGE_SUB_CLS           ,
CREDIT_FLAG             ,
MORTAGAGE_FLAG          ,
IMPAWN_FLAG             ,
PLEDGE_FLAG             ,
DLGT_CORP_ID            ,
DLGT_CORP_CONTACT       ,
DLGT_CORP_TEL           ,
HAND_CHRG_TYPE          ,
HAND_CHRG_RATE          ,
HAND_CHRG_SIDE          ,
DLGT_ACCT_NO            ,
DLGT_INST_ACCT          ,
SELLED_FLAG             ,
NOW_AUDITOR             ,
FINAL_AUDITOR           ,
FINAL_AUDIT_TIME        ,
CAL_INST_TYPE           ,
SPARE1                  ,
SPARE2                  ,
SPARE3                  ,
CYCLE_FLAG              ,
ASSURE_TYPE             ,
REPAY_SOURCE_TYPE       ,
RATE_MOD_TYPE           ,
ISBUYOUT                ,
OR_APPLY_CODE           ,
PRO_APPLY_AMOUNT        ,
ISPROMISES              ,
HOLIDAY_PROCESS_FLAG    ,
NORMAL_RATE             ,
RATE_FLTT_TYPE          ,
RATE_FLTT_BADD          ,
CNTT_ATERM_STATE        ,
INST_RATE_MONTH         ,
OVERDUE_RATE_MONTH      ,
APPROP_RATE_MONTH       ,
''
FROM LN_LOAN_CNTT z
WHERE z.BORROWER_ID IS NOT NULL;
COMMIT;
DELETE FROM SYN_LN_PRIN_WASTE_BOOK;
COMMIT;
INSERT INTO SYN_LN_PRIN_WASTE_BOOK
SELECT PRIN_WASTE_BOOK_ID   ,
ORG_CODE             ,
BORROWER_ID          ,
DLGT_CORP_ID         ,
PROD_CODE            ,
CNTT_CODE            ,
DFRD_CNTT_CODE       ,
PRVD_INFM_CODE       ,
REPAY_EXE_CODE       ,
SUMMERY              ,
CHANGE_AMT           ,
RECORD_DATE          ,
RECORDER             ,
STATE                ,
REMARK               ,
VALID_DATE           ,
VOUCHER_CODE         ,
DFRD_FLAG            ,
AUDT_DATE            ,
AUDITOR              ,
AHEAD_REPAY_FLAG     ,
HAND_FLAG            ,
RETURNED_FLAG        ,
SPARE1               ,
SPARE2               ,
SPARE3               ,
ISBUYOUT             
 FROM ln_prin_waste_book;
COMMIT;
DELETE FROM SYN_LN_JOINER_PRIN_WASTE_BOOK;
INSERT INTO SYN_LN_JOINER_PRIN_WASTE_BOOK
SELECT PRIN_WASTE_BOOK_ID     ,
VALID_DATE                    ,
PROD_CODE                     ,
CNTT_CODE                     ,
PRVD_INFM_CODE                ,
REPAY_EXE_PLAN                ,
PRIN_WASTE_BOOK_ID            ,
JOINER_ID                     ,
JOINER_NAME                   ,
AMOUNT                        ,
VOUCHER_CODE                  ,
SUMMERY                       ,
RETURNED_AMOUNT               ,
RECORDER_ID                   ,
RECORD_TIME                   ,
CHECKER_ID                    ,
CHECK_TIME                    ,
'' AS HAND_FLAG                     ,
STATE                         ,
''                         ,
''                         ,
''                         ,
'' AS IS_CESSION                    ,
''AS IS_ACCEPT                     ,
IS_ORG                        
FROM LN_JOINER_PRIN_WASTE_BOOK;
COMMIT;
DELETE FROM syn_ln_guaranty_desc;
COMMIT;
INSERT INTO syn_ln_guaranty_desc t
SELECT GUARANTY_ID                     ,
GUARANTY_GRP_ID                 ,
WARRANTOR_ID                    ,
WARRANTOR_NAME                  ,
GUARANTY_MODE                   ,
GUARANTY_AMT                    ,
GUARANTY_TYPE                   ,
GUARANTY_NAME                   ,
GUARANTY_VALUE                  ,
GUARANTY_RATE                   ,
ASSURANCE_TERM                  ,
STORE_PLACE                     ,
FSCL_YEAR                       ,
REMARK                          ,
SPARE1                          ,
SPARE2                          ,
SPARE3                          ,
APPLY_AMT                       ,
INST                            ,
TOTAL_INST                      ,
INCLUDE_INST_FLAG               ,
GUARANTY_RATE_INCLUDE_INST      ,
LOAN_BAL                        ,
GUARANTY_FOREIGN_BAL            ,
IMPAWN_RATE                     ,
'' GUARANTY_CNTT_CODE              ,
'' GUARANTY_CNTT_DATE              ,
'' GUARANTY_CNTT_NAME              
 FROM ln_guaranty_desc;
COMMIT;

end ri_loan_etl;
/

