CREATE VIEW LN_PRVD_EXE AS
  SELECT A.SEQNO PRVD_EXE_CODE, -- 放款执行计划编码
       A.CONTRACTNO CNTT_CODE, --  合同编码
       A.PLAN_DATE PRVD_DATE, --  计划放款日期
       A.PLAN_AMT PRVD_AMT, --  计划放款金额
       A.PLAN_REPAY_DATE REPAY_DATE, --  截止还款日期
       '' SPARE1, --备用1
       '' SPARE2 --备用2
  FROM BUSI_PUTOUT_PLAN_DETAIL A
/

