CREATE VIEW RI_VIEW_FACTOR_PRINTINFO AS
  select a.cntt_code asset_id,a.acct_period,a.cntt_org_code asset_org,b.type,a.sort,a.sort_desc,a.remark,b.oper_org,
(select org_name from ri_org_info where org_code=b.oper_org) as oper_org_name,
b.operator_id,
(select person_name from au_employee where id=b.operator_id) as operator,
b.oper_time,
b.report_person,
(select person_name from au_employee where id=b.report_person) as reportor,
b.report_time
from RI_FACTORASSETRESULT a, RI_FACTORASSETSORTDETAIL b
where a.sort_id=b.sort_id and a.state>=b.type
/

