CREATE VIEW RI_VIEW_LOAN_DETAIL AS
  SELECT a.sort_id,
       a.acct_period,
       a.cntt_code,
       a.cntt_balance,
       --(select sort from (select sort,sort_id,row_number() over(partition by sort_id order by type desc) zz from
--ri_assetsortdetail where sort_id=a.sort_id) where zz=1 and sort_id=a.sort_id) sort,
       g.sort sort,
       g.sort_desc,
       a.cntt_org_code,
       --SUBSTR(a.cntt_org_code, 0, 2) as parent_code,
       (select parent_code from ri_org_info where org_code=a.cntt_org_code) as parent_code,
       b.loan_amt,
       b.borrower_id,
       b.start_date,
       b.end_date,
       (SELECT code FROM RI_CUSTBASEINFO WHERE cust_id(+) = b.borrower_id) AS borrower_code,
       (SELECT name FROM RI_CUSTBASEINFO WHERE cust_id(+) = b.borrower_id) AS borrower_name,
       /*(select target_value
          from ri_assettargetresult
         where sort_id = a.sort_id
           and target_id = '100000130') AS prin_overdue_dayes,*/
       c.prin_overdue_days  as prin_overdue_dayes,
       /*(SELECT SUM(change_amt)
          FROM RI_LOAN_PRINWASTEBOOK
         WHERE cntt_code(+) = a.cntt_code
           AND TO_DATE(repay_date, 'yyyy-mm-dd') <
               LAST_DAY(TO_DATE(a.ACCT_PERIOD, 'yyyy-mm-dd'))
           AND TO_DATE(valid_date, 'yyyy-mm-dd') <=
               LAST_DAY(TO_DATE(a.ACCT_PERIOD, 'yyyy-mm-dd'))) AS overdue_prin, */
       c.prin_overdue_amt AS overdue_prin,
       /* (SELECT LAST_DAY(TO_DATE(a.ACCT_PERIOD, 'yyyy-mm-dd')) -
               TO_DATE(MIN(biz_date), 'yyyy-MM-dd')
          FROM RI_LOAN_INSTWASTEBOOK
         WHERE cntt_code = a.cntt_code
           AND LAST_DAY(TO_DATE(a.ACCT_PERIOD, 'yyyy-mm-dd')) >
               TO_DATE(biz_date, 'yyyy-MM-dd')
           AND NVL(should_receive_inst, 0) - NVL(already_receive_inst, 0) > 0) AS inst_overdue_days,*/
      d.inst_overdue_days,
       /*(SELECT SUM(NVL(should_receive_inst, 0) -
                   NVL(already_receive_inst, 0))
          FROM RI_LOAN_INSTWASTEBOOK
         WHERE cntt_code(+) = a.cntt_code
           AND TO_DATE(biz_date, 'yyyy-mm-dd') <
               LAST_DAY(TO_DATE(a.ACCT_PERIOD, 'yyyy-mm-dd'))) AS overdue_inst*/
      d.overdue_inst
  FROM RI_ASSETRESULT a, RI_LOAN_BASEINFO b,ri_loan_prin_overdue c,ri_loan_inst_overdue d,(select sort,sort_id,sort_desc from (select sort,sort_id,sort_desc,row_number() over(partition by sort_id order by type desc) zz from
ri_assetsortdetail ) where zz=1 ) g
 WHERE a.cntt_code = b.cntt_code
 --and a.sort_id=c.sort_id
 --and a.sort_id=d.sort_id
 and a.cntt_code=c.cntt_code(+) and a.acct_period=c.acct_period(+)
 and a.cntt_code=d.cntt_code(+) and a.acct_period=d.acct_period(+)
 and g.sort_id(+)=a.sort_id
/

