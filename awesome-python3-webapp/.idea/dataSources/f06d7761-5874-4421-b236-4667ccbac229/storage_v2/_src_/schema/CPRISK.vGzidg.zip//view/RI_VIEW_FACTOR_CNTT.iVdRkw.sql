CREATE VIEW RI_VIEW_FACTOR_CNTT AS
  SELECT A.CONTRACTNO, --保理合同编号
       REBCHID, --经营机构
       SELLERID, --销货方编号
       SELLERNAME, --销货方名称
       CONTRACTAMT, --合同金额
       (SELECT sum(nvl(LOANBALANCE,0))+sum(nvl(OVERDUEAMOUNT,0)) FROM RI_FINT_LOANM e WHERE e.SUBCONTRACTID IN (SELECT b.id FROM RI_FBUS_SUBCM b WHERE b.contractid=a.id)) AS loan_bal  , --合同余额
       c.cntt_balance,
       STARTDATE, --合同起始日期
       ENDDATE,--合同结束日期
       c.acct_period,
       c.cntt_code asset_id
  FROM RI_FBUS_CTCTM A,RI_FACTORASSETRESULT c
 WHERE a.contractno=c.cntt_code and A.STATE <> '2'
/

