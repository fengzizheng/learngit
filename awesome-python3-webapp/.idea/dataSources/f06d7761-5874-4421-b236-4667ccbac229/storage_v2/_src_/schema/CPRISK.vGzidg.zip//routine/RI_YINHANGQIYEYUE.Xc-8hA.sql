CREATE PROCEDURE ri_yinhangqiyeyue(b_bizdtae in varchar2) is

p_bizdate DATE;

BEGIN
p_bizdate:=to_date(b_bizdtae,'yyyy-mm-dd');
--银行存款
DELETE FROM ln_bank_business_bal WHERE biz_date=b_bizdtae AND biaoshi='0';
COMMIT;
INSERT INTO ln_bank_business_bal
SELECT b_bizdtae, ORG_CODE, SUM(nvl(bal,0)) AS BAL,'0','','',''
  FROM (SELECT TRUNC((TO_DATE('1970/01/01', 'yyyy/mm/dd') +
                     A.SHIJCHUO / (1000 * 60 * 60 * 24)),
                     'dd') AS BIZ_DATE,
               A.KAIHJGHA AS ORG_CODE,
               A.SRZHHUYE AS BAL
          FROM KTAB_CFTYHQ A
         WHERE A.JILUZTAI = '0'
          AND to_date(KAIHURIQ,'yyyy-mm-dd')<=p_bizdate
        UNION ALL
        SELECT TRUNC((TO_DATE('1970/01/01', 'yyyy/mm/dd') +
                     A.SHIJCHUO / (1000 * 60 * 60 * 24)),
                     'dd') AS BIZ_DATE,
               A.KAIHJGHA AS ORG_CODE,
               A.SRZHHUYE AS BAL
          FROM KTAB_CFTYDQ A
         WHERE A.JILUZTAI = '0'
         AND to_date(KAIHURIQ,'yyyy-mm-dd')<=p_bizdate)
 WHERE BIZ_DATE <= P_BIZDATE
 GROUP BY org_code;
COMMIT;

--企业存款余额
DELETE FROM ln_bank_business_bal WHERE biz_date=b_bizdtae AND biaoshi='1';
COMMIT;
INSERT INTO ln_bank_business_bal
SELECT b_bizdtae, ORG_CODE, SUM(NVL(BAL, 0)) AS BAL,'1','','',''
  FROM (SELECT TRUNC((TO_DATE('1970/01/01', 'yyyy/mm/dd') +
                     A.SHIJCHUO / (1000 * 60 * 60 * 24)),
                     'dd') AS BIZ_DATE,
               A.KAIHJIGO AS ORG_CODE,
               A.SHRIZHYE AS BAL
          FROM KDPA_ZHXINX A
         WHERE to_date(KAIHRIQI,'yyyy-mm-dd') <= p_bizdate)
 WHERE BIZ_DATE <= p_bizdate
 GROUP BY ORG_CODE;
 COMMIT;
END ri_yinhangqiyeyue;
/

