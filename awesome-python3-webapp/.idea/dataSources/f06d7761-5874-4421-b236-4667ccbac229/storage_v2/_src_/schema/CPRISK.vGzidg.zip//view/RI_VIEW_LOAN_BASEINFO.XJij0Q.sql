CREATE VIEW RI_VIEW_LOAN_BASEINFO AS
  select a.code,
       a.name,
       a.ARTIFICIAL,
       a.reg_capt,
       a.cust_type2,
       a.cust_type2_desc,
       b.cntt_code,
       b.cntt_code as asset_id,
       b.LOAN_AMT,
       b.LOAN_TERM,
       b.REPAY_SOURCE_TYPE,
       b.SIGN_DATE,
       b.USAGE,
       nvl((select CREDIT_FLAG from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code and start_date=
       (select max(start_date)from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code )),b.CREDIT_FLAG ) as CREDIT_FLAG,
       nvl((select IMPAWN_FLAG from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code and start_date=
       (select max(start_date)from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code )),b.IMPAWN_FLAG ) as IMPAWN_FLAG,
       nvl((select MORTAGAGE_FLAG from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code and start_date=
       (select max(start_date)from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code )),b.MORTAGAGE_FLAG ) as MORTAGAGE_FLAG,
       nvl((select PLEDGE_FLAG from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code and start_date=
       (select max(start_date)from syn_ln_cntt_change where state=3 and cntt_code=b.cntt_code )),b.PLEDGE_FLAG ) as PLEDGE_FLAG,
       c.VALID_DATE,
       c.SUMMERY,
       (SELECT NAME
          FROM sm_codetable
         Where TYPE_CODE = '5'
           and code = c.SUMMERY) SUMMERY_DESC,
       c.REPAY_EXE_CODE,
       c.REPAY_DATE,
       c.VOUCHER_CODE,

       (
/*       SELECT no
          FROM gl_voucher, syn_bd_system
         WHERE gl_voucher.pk_system = syn_bd_system.pk_system(+)
           and gl_voucher.pk_voucher = c.VOUCHER_CODE*/
           c.voucher_code

           ) as VOUCHER_show_CODE,
       c.CHANGE_AMT,
       c.DFRD_CNTT_CODE
  from ri_custbaseinfo a, ri_loan_baseinfo b, ri_loan_prinwastebook c
 where a.cust_id = b.borrower_id
   and b.cntt_code = c.cntt_code
/

