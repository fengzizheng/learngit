CREATE VIEW RI_VIEW_OTHER_SORTRESULT AS
  select a.result_id,a.rpt_id,a.asset_id,
d.other_type,d.other_type_2,d.project_name,d.balance,
a.acct_period,a.asset_org,SUBSTR ( a.asset_org, 0, 2 ) as parent_code,b.org_name,a.asset_balance,a.state,a.sort,a.sort_desc,a.remark,
decode(a.sort,5011,a.asset_balance,5016,a.asset_balance,'') as sort_1,
decode(a.sort,5012,a.asset_balance,'') as sort_2,
decode(a.sort,5013,a.asset_balance,'') as sort_3,
decode(a.sort,5014,a.asset_balance,'') as sort_4,
decode(a.sort,5015,a.asset_balance,'') as sort_5,
        (SELECT e.sort_desc
            FROM ri_otherasset_result e
           WHERE e.asset_id = a.asset_id and e.asset_org=a.asset_org
           and e.acct_period in(select max(acct_period) from ri_otherasset_result where asset_id = a.asset_id and asset_org=a.asset_org and acct_period<a.acct_period)
         ) AS pre_sort,
         (select sum(asset_balance) from ri_otherasset_result
where sort in ('5013','5014','5015')
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
from ri_otherasset_result a,ri_org_info b,ri_otherasset_other d
where a.asset_org=b.ORG_CODE
and a.ASSET_TYPE='10005'
and a.asset_id=d.asset_id and a.rpt_id=d.rpt_id
/

