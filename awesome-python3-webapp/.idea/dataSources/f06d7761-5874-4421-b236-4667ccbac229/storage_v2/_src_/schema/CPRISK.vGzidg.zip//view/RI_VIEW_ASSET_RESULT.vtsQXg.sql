CREATE VIEW RI_VIEW_ASSET_RESULT AS
  select '信贷类资产' as type,1 as no_id,'20001' asset_type,'自营贷款' as sub_type,'' as sub_type_2,a.cntt_code asset_id, a.cntt_balance asset_balance, a.acct_period,
a.cntt_org_code asset_org,
--SUBSTR ( a.cntt_org_code, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,
--(select sort from (select sort,sort_id,row_number() over(partition by sort_id order by type desc) zz from
--ri_assetsortdetail where sort_id=a.sort_id) where zz=1 and sort_id=a.sort_id) sort,
g.sort sort,
decode(g.sort,1,a.cntt_balance,2,a.cntt_balance,3,a.cntt_balance,'') as sort_1,
decode(g.sort,4,a.cntt_balance,5,a.cntt_balance,6,a.cntt_balance,'') as sort_2,
decode(g.sort,7,a.cntt_balance,8,a.cntt_balance,'') as sort_3,
decode(g.sort,9,a.cntt_balance,'') as sort_4,
decode(g.sort,10,a.cntt_balance,'') as sort_5,
(select sum(cntt_balance)
          from ri_assetresult e,
          (select sort,sort_id,sort_desc from (select sort,sort_id,sort_desc,row_number() over(partition by sort_id order by type desc) zz from
ri_assetsortdetail ) where zz=1 ) r
         where r.sort>6
           and e.sort_id = a.sort_id and r.sort_id(+)=e.sort_id ) as abnormal_balance
from ri_assetresult a,ri_org_info b
,(select sort,sort_id from (select sort,sort_id,row_number() over(partition by sort_id order by type desc) zz from
ri_assetsortdetail ) where zz=1 ) g
where a.cntt_org_code=b.ORG_CODE and g.sort_id(+)=a.sort_id
/*union
select '股权投资资产' type,4 as no_id,'20006' asset_type,c.stock_type as sub_type,'' as sub_type_2,a.asset_id, a.asset_balance,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,a.sort,
decode(a.sort,1,a.asset_balance,a.sort,2,a.asset_balance,a.sort,3,a.asset_balance,'') as sort_1,
decode(a.sort,4,a.asset_balance,a.sort,5,a.asset_balance,a.sort,6,a.asset_balance,'') as sort_2,
decode(a.sort,7,a.asset_balance,a.sort,8,a.asset_balance,'') as sort_3,
decode(a.sort,9,a.asset_balance,'') as sort_4,
decode(a.sort,10,a.asset_balance,'') as sort_5,
(select sum(asset_balance) from ri_otherasset_result
where sort>6
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
from ri_otherasset_result a,ri_org_info b,ri_otherasset_stock c
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.rpt_id=c.rpt_id and asset_type='10001'*/
union
select '同业债权资产' type,2 as no_id,'20004' asset_type,c.creditright_type as sub_type,'' as sub_type_2,a.asset_id, a.asset_balance,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,a.sort,
decode(a.sort,5011,a.asset_balance,'') as sort_1,
decode(a.sort,5012,a.asset_balance,'') as sort_2,
decode(a.sort,5013,a.asset_balance,'') as sort_3,
decode(a.sort,5014,a.asset_balance,'') as sort_4,
decode(a.sort,5015,a.asset_balance,'') as sort_5,
(select sum(asset_balance) from ri_otherasset_result
where sort in ('5013','5014','5015')
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
from ri_otherasset_result a,ri_org_info b,ri_otherasset_creditright c
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.rpt_id=c.rpt_id and asset_type='10003'
union
select '信贷类资产' as type,1 as no_id,'20002' asset_type,'融资租赁' as sub_type,'' as sub_type_2,a.asset_id, a.asset_balance,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,a.sort,
decode(a.sort,1,a.asset_balance,2,a.asset_balance,3,a.asset_balance,'') as sort_1,
decode(a.sort,4,a.asset_balance,5,a.asset_balance,6,a.asset_balance,'') as sort_2,
decode(a.sort,7,a.asset_balance,8,a.asset_balance,'') as sort_3,
decode(a.sort,9,a.asset_balance,'') as sort_4,
decode(a.sort,10,a.asset_balance,'') as sort_5,
(select sum(asset_balance) from ri_otherasset_result
where sort>6
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
from ri_otherasset_result a,ri_org_info b
where a.asset_org=b.ORG_CODE and asset_type ='10004'
union
select '信贷类资产' as type,1 as no_id,'20003' asset_type,'票据贴现' as sub_type,'' as sub_type_2,a.asset_id, a.asset_balance,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,a.sort,
decode(a.sort,1,a.asset_balance,2,a.asset_balance,3,a.asset_balance,'') as sort_1,
decode(a.sort,4,a.asset_balance,5,a.asset_balance,6,a.asset_balance,'') as sort_2,
decode(a.sort,7,a.asset_balance,8,a.asset_balance,'') as sort_3,
decode(a.sort,9,a.asset_balance,'') as sort_4,
decode(a.sort,10,a.asset_balance,'') as sort_5,
(select sum(asset_balance) from ri_otherasset_result
where sort>6
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
from ri_otherasset_result a,ri_org_info b
where a.asset_org=b.ORG_CODE and asset_type ='10006'
union
select '信贷类资产' as type,1 as no_id,'20008' asset_type,'保理' as sub_type,'' as sub_type_2,a.cntt_code asset_id, a.cntt_balance asset_balance,a.acct_period,a.cntt_org_code asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,a.sort,
decode(a.sort,1,a.cntt_balance,2,a.cntt_balance,3,a.cntt_balance,'') as sort_1,
decode(a.sort,4,a.cntt_balance,5,a.cntt_balance,6,a.cntt_balance,'') as sort_2,
decode(a.sort,7,a.cntt_balance,8,a.cntt_balance,'') as sort_3,
decode(a.sort,9,a.cntt_balance,'') as sort_4,
decode(a.sort,10,a.cntt_balance,'') as sort_5,
(select sum(cntt_balance) from RI_FACTORASSETRESULT
where sort>6
and cntt_code=a.cntt_code) as abnormal_balance
from RI_FACTORASSETRESULT a,ri_org_info b
where a.cntt_org_code=b.ORG_CODE
union
select  '其他类资产' as type,5 as no_id,'20007' asset_type,c.other_type as sub_type,c.other_type_2 as sub_type_2,a.asset_id, a.asset_balance,a.acct_period,a.asset_org,
--SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
b.parent_code as parent_code,
b.org_name,a.state,a.sort,
decode(a.sort,5011,a.asset_balance,'') as sort_1,
decode(a.sort,5012,a.asset_balance,'') as sort_2,
decode(a.sort,5013,a.asset_balance,'') as sort_3,
decode(a.sort,5014,a.asset_balance,'') as sort_4,
decode(a.sort,5015,a.asset_balance,'') as sort_5,
(select sum(asset_balance) from ri_otherasset_result
where sort in ('5013','5014','5015')
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
from ri_otherasset_result a,ri_org_info b,ri_otherasset_other c
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.rpt_id=c.rpt_id and asset_type='10005' and c.other_type<>'资产损失准备' and (c.other_type_2<>'非提取项' or c.other_type_2 is null)
union
select '证券投资类资产' as type,
       3 as no_id,
       '20005' as asset_type,
       r.paper_type as sub_type,
       '' as sub_type_2,
       r.asset_id,
       r.asset_balance,
       r.acct_period,
       r.asset_org,
       r.parent_code,
       r.org_name,
       r.state,
       r.sort,
       (select sort_value from ri_otherasset_paper_result where sort = 1 and asset_id = r.asset_id and rpt_id = r.rpt_id and result_id=r.result_id) as sort_1,
       (select sort_value from ri_otherasset_paper_result where sort = 2 and asset_id = r.asset_id and rpt_id = r.rpt_id and result_id=r.result_id) as sort_2,
       (select sort_value from ri_otherasset_paper_result where sort = 3 and asset_id = r.asset_id and rpt_id = r.rpt_id and result_id=r.result_id) as sort_3,
       (select sort_value from ri_otherasset_paper_result where sort = 4 and asset_id = r.asset_id and rpt_id = r.rpt_id and result_id=r.result_id) as sort_4,
       (select sort_value from ri_otherasset_paper_result where sort = 5 and asset_id = r.asset_id and rpt_id = r.rpt_id and result_id=r.result_id) as sort_5,
       (select sum(sort_value) from ri_otherasset_paper_result where sort in ('3', '4', '5') and asset_id = r.asset_id and result_id=r.result_id) as abnormal_balance
  from (select distinct a.asset_id,a.rpt_id,a.paper_type,a.book_value as asset_balance, a.asset_org,a.result_id,
                        --SUBSTR ( a.asset_org, 0, 2 ) as parent_code,
                        b.parent_code, b.org_name, max(a.state) state,a.remark,a.acct_period,
                        max(a.sort) as sort
          from ri_otherasset_paper_result a, ri_org_info b
         where a.asset_org = b.ORG_CODE
         group by a.rpt_id,a.asset_id,a.paper_type,a.book_value,a.asset_org,b.parent_code,b.org_name,a.state,a.remark,a.acct_period,a.result_id) r
/

