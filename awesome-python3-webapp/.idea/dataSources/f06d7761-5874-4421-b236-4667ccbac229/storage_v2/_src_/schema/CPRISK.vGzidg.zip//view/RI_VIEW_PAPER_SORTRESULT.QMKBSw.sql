CREATE VIEW RI_VIEW_PAPER_SORTRESULT AS
  select r.rpt_id,r.asset_id,r.paper_type,r.asset_item,r.asset_item_sort,r.book_value,r.market_value,r.profit_loss,r.asset_org,r.parent_code,r.org_name,r.state,r.remark,r.acct_period,
(select sort_value from ri_otherasset_paper_result where sort=1 and asset_id=r.asset_id and result_id=r.result_id) as sort_1,
(select sort_value from ri_otherasset_paper_result where sort=2 and asset_id=r.asset_id and result_id=r.result_id) as sort_2,
(select sort_value from ri_otherasset_paper_result where sort=3 and asset_id=r.asset_id and result_id=r.result_id) as sort_3,
(select sort_value from ri_otherasset_paper_result where sort=4 and asset_id=r.asset_id and result_id=r.result_id) as sort_4,
(select sort_value from ri_otherasset_paper_result where sort=5 and asset_id=r.asset_id and result_id=r.result_id) as sort_5,
(select sum(sort_value) from ri_otherasset_paper_result
where sort>2
and asset_id=r.asset_id ) as abnormal_balance
from (
select distinct a.result_id,a.rpt_id,a.asset_id,a.paper_type,a.asset_item,a.asset_item_sort,a.book_value,a.market_value,a.profit_loss,a.asset_org,SUBSTR ( a.asset_org, 0, 2 ) as parent_code,b.org_name,a.state,a.remark,a.acct_period
from ri_otherasset_paper_result a,ri_org_info b
where a.asset_org=b.ORG_CODE
) r
/

