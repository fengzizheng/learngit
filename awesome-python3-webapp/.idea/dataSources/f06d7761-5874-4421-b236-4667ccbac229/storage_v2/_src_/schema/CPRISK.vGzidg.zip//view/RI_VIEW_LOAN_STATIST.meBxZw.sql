CREATE VIEW RI_VIEW_LOAN_STATIST AS
  select decode(b.cycle_flag, '1', 'cycle', b.term_cls) term_cls,
       a.acct_period,
       a.cntt_code,
       a.cntt_org_code,
       a.cntt_balance,
       (select cntt_balance
          from ri_assetresult
         where cntt_code = a.cntt_code
           and acct_period in
               (select max(acct_period)
                  from ri_assetresult
                 where acct_period < a.acct_period
                   and cntt_code = a.cntt_code)) as pre_balance,
       /*(select sum(change_amt)
          from ri_loan_prinwastebook
         where summery = 1
           and cntt_code = a.cntt_code
           and (valid_date >= to_char(to_date(a.acct_period, 'yyyy-MM-DD'),
                                      'YYYY') || '-01-01' and
               valid_date <=
               to_char(last_day(to_date(a.acct_period, 'yyyy-MM-DD')),
                        'yyyy-MM-DD'))) year_sum_prvd_amt,*/
       c.year_sum_prvd_amt,
       /*(select sum(change_amt)
          from ri_loan_prinwastebook
         where summery = 1
           and cntt_code = a.cntt_code
           and (valid_date >= to_char(to_date(a.acct_period, 'yyyy-MM-DD'),
                                      'YYYY-MM') || '-01' and
               valid_date <=
               to_char(last_day(to_date(a.acct_period, 'yyyy-MM-DD')),
                        'yyyy-MM-DD'))) period_sum_prvd_amt,*/
       c.period_sum_prvd_amt,
       /*(select sum(change_amt)
          from ri_loan_prinwastebook
         where summery = 2
           and cntt_code = a.cntt_code
           and (valid_date >= to_char(to_date(a.acct_period, 'yyyy-MM-DD'),
                                      'YYYY-MM') || '-01' and
               valid_date <=
               to_char(last_day(to_date(a.acct_period, 'yyyy-MM-DD')),
                        'yyyy-MM-DD'))) period_sum_repy_amt,*/
       c.period_sum_repy_amt,
       /*(select sum(change_amt)
          from ri_loan_prinwastebook
         where summery = 3
           and cntt_code = a.cntt_code
           and (valid_date >= to_char(to_date(a.acct_period, 'yyyy-MM-DD'),
                                      'YYYY-MM') || '-01' and
               valid_date <=
               to_char(last_day(to_date(a.acct_period, 'yyyy-MM-DD')),
                        'yyyy-MM-DD'))) period_sum_dfrd_amt,*/
       c.period_sum_dfrd_amt,
       /*(SELECT sum(nvl(should_receive_inst, 0) -
                   nvl(already_receive_inst, 0))
          FROM RI_LOAN_INSTWASTEBOOK
         WHERE cntt_code = a.cntt_code
           AND to_date(biz_date, 'YYYY-MM-DD') <=
               last_day(to_date(a.acct_period, 'YYYY-MM-DD'))
         GROUP BY cntt_code) as inst_bal */
       d.inst_bal
  from ri_assetresult a, ri_loan_baseinfo b,ri_loan_sum c,ri_loan_inst_overdue d
 where a.cntt_code = b.cntt_code
 --and a.sort_id=c.sort_id
 --and a.sort_id=d.sort_id
 and a.cntt_code=c.cntt_code(+) and a.acct_period=c.acct_period(+)
 and a.cntt_code=d.cntt_code(+) and a.acct_period=d.acct_period(+)
/

