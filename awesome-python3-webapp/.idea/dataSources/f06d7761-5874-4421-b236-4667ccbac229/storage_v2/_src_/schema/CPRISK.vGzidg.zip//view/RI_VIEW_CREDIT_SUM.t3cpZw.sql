CREATE VIEW RI_VIEW_CREDIT_SUM AS
  select asset_type,asset_org,acct_period,sum(asset_balance) asset_balance
from ri_otherasset_result where asset_type in ('10004','10006') group by  asset_type,asset_org,acct_period
union
select '10000' asset_type,cntt_org_code asset_org,acct_period,sum(cntt_balance) asset_balance
from ri_assetresult group by  cntt_org_code,acct_period
/

