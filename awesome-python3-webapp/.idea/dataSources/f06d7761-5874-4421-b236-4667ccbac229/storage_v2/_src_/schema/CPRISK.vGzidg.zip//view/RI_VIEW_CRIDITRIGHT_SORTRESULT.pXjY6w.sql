CREATE VIEW RI_VIEW_CRIDITRIGHT_SORTRESULT AS
  SELECT   a.result_id, a.rpt_id, a.asset_id, d.creditright_type,
         d.project_name, a.acct_period, a.asset_org,SUBSTR ( a.asset_org, 0, 2 ) as parent_code, b.org_name, d.balance,
         a.asset_balance, a.state, a.sort, a.sort_desc, a.remark,
         DECODE (a.sort, 5011, a.asset_balance, '') AS sort_1,
         DECODE (a.sort, 5012, a.asset_balance, '') AS sort_2,
         DECODE (a.sort, 5013, a.asset_balance, '') AS sort_3,
         DECODE (a.sort, 5014, a.asset_balance, '') AS sort_4,
         DECODE (a.sort, 5015, a.asset_balance, '') AS sort_5,
(SELECT e.sort_desc
            FROM ri_otherasset_result e
           WHERE e.asset_id = a.asset_id and e.asset_org=a.asset_org
           and e.acct_period in(select max(acct_period) from ri_otherasset_result where asset_id = a.asset_id and asset_org=a.asset_org and acct_period<a.acct_period)
         ) AS pre_sort,
       (select sum(asset_balance) from ri_otherasset_result
where sort in ('5013','5014','5015')
and asset_id=a.asset_id and rpt_id=a.rpt_id) as abnormal_balance
    FROM ri_otherasset_result a, ri_org_info b, ri_otherasset_creditright d
   WHERE a.asset_org = b.org_code
     AND a.asset_type = '10003'
     AND a.asset_id = d.asset_id
     AND a.rpt_id = d.rpt_id
/

