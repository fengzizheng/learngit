CREATE VIEW LN_REPAY_PLAN AS
  select repay_exe_code,(select seqno from busi_putout_plan_detail where contractno=a.cntt_code)  prvd_exe_plan_code,
  pre_repay_exe_code, cntt_code, prvd_infm_code,(select plan_repay_date from busi_putout_plan_detail where contractno=a.cntt_code) repay_date, repay_amt, at_term_state, spare1, spare2, delay_repay_date
  from (select t.seqno repay_exe_code, --  还款执行计划编码
                '' prvd_exe_plan_code, --  放款执行计划编码
                '' pre_repay_exe_code, -- 原还款执行计划编码
                (select distinct contractno
                    from busi_duebill
                   where duebillno = t.putoutno) cntt_code, -- 合同编码/展期合同编码
                '' prvd_infm_code, --放款通知单编码
                '' repay_date, -- 计划还款日期
                '' repay_amt, -- 计划还款金额
                '' at_term_state, --  到期状态
                '' spare1, -- 备用1
                '' spare2, -- 备用2
                '' delay_repay_date --计划还款日期显示用
           from busi_repay_plan_detail t) a
/

