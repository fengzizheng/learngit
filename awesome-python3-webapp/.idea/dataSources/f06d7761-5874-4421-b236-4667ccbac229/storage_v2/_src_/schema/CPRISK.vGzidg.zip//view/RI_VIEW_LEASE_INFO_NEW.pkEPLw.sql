CREATE VIEW RI_VIEW_LEASE_INFO_NEW AS
  select a1."CNTT_CODE",
       a1."LEASER",
       a1."CNTT_COST",
       a1."RATE",
       a1."LEASE_DATE",
       to_char(a1.PERIOD) period,
       a1."WARRANTY",
       a1."FEE",
       a1."GUARANTY_MODE",
       a1."CREDIT_FLAG",
       a1."MORTAGAGE_FLAG",
       a1."IMPAWN_FLAG",
       a1."PLEDGE_FLAG",
       a1."INVEST_STRU",
       a1."REMARK",
       a1."CUST_ID",
       a1."CUST_CODE",
       a1."IS_RATECHANGE",
       a1."IS_CNTTCHANGE",
       a1."IS_RETURN",
       a1."OP_DATE",
       a1."ORG_CODE",
       a1."INVT_CLS",
       a2.acct_period,
       a1. leasehold_type
  from ri_lease_info a1,
       (select cntt_code, acct_period, max(op_date) latest_date
          from (select t1.op_date, t1.cntt_code, t2.acct_period
                  from ri_lease_info         t1,
                       ri_otherasset_result  t2,
                       ri_otherasset_rptinfo t3
                 where t1.cntt_code = t2.asset_id
                   and t2.asset_type = '10004'
                   and t2.rpt_id = t3.rpt_id
                   and t3.import_flag = 'N'
                   and to_date(t1.op_date, 'yyyy-mm-dd') <=
                       last_day(to_date(t2.acct_period, 'yyyy-mm-dd')))
         group by cntt_code, acct_period) a2
 where a1.cntt_code = a2.cntt_code
   and a1.op_date = a2.latest_date
union
-- add by YiDehong   union import data
select v1."ASSET_ID" CNTT_CODE,
       v1."LEASER",
       v1."CNTT_AMT",
       v1."RATE",
       v1."LEASE_DATE",
       v1."PERIOD",
       v1."WARRANTY",
       v1."FEE",
       '' as GUARANTY_MODE,
       '' CREDIT_FLAG,
       '' as MORTAGAGE_FLAG,
       '' as IMPAWN_FLAG,
       '' as PLEDGE_FLAG,
       v1."INVEST_STRU",
       v1."REMARK",
       v1."CUST_ID",
       v1."CUST_CODE",
       v1.is_chg_rate IS_RATECHANGE,
       v1.is_chg_cntt IS_CNTTCHANGE,
       v1.is_chg_tz IS_RETURN,
       v3.rpt_DATE,
       v2.asset_org org_code,
       '' as INVT_CLS,
       v2.acct_period,
       v1.leasehold_type
  from ri_otherasset_lease   v1,
       ri_otherasset_result  v2,
       ri_otherasset_rptinfo v3
 where v1.asset_id = v2.asset_id
   and v1.rpt_id = v2.rpt_id
   and v1.rpt_id = v3.rpt_id
   and v3.rpt_type = '10004'
   and v3.import_flag is null
/

