CREATE VIEW RI_VIEW_STOCK_DETAIL AS
  SELECT distinct
   a."DATA_ID",a."RPT_ID",a."ASSET_ID",a."STOCK_TYPE",a."PROJECT_NAME",a."BALANCE",a."SORT",a."SORT_DESC",a."SORT_STANDARD",a."REMARK",
   b.ACCT_PERIOD,b.ASSET_ORG,c.ORG_NAME,
   d.rpt_date,
   (select e.sort_desc from ri_otherasset_result e where e.acct_period=TO_CHAR(add_months(to_date(b.acct_period,'yyyy-MM-DD'),-1),'yyyy-MM-DD') and e.ASSET_ID=a.asset_id) as pre_sort
FROM RI_OTHERASSET_stock a,RI_OTHERASSET_RESULT b,ri_org_info c, ri_otherasset_rptinfo d
where a.rpt_id=b.rpt_id and b.ASSET_ORG=c.ORG_CODE and a.rpt_id=d.rpt_id
/

