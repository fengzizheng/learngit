CREATE VIEW RI_VIEW_LEASE_STATIST_ORG AS
  select w1."ACCT_PERIOD",w1."CNTT_ORG_CODE",w1."NUM",w1."CNTT_BALANCE",w1."YEAR_SUM_PRVD_AMT",w1."PERIOD_SUM_PRVD_AMT",w1."PERIOD_SUM_REPY_AMT",w1."PERIOD_SUM_DFRD_AMT",w1."INST_BAL",w2.pre_balance from
(
select acct_period,cntt_org_code, count(*) num,sum(cntt_balance) cntt_balance ,sum(year_sum_prvd_amt) year_sum_prvd_amt,sum(period_sum_prvd_amt) period_sum_prvd_amt,sum(period_sum_repy_amt) period_sum_repy_amt, 0 period_sum_dfrd_amt,sum(inst_bal) inst_bal
from (
select a.acct_period,a.asset_org cntt_org_code, a.asset_balance cntt_balance,
(select amount from syn_fl_contract_baseinfo where state<>0 and contract_id=d.contract_id and (start_date>=to_char(to_date(a.acct_period,'yyyy-MM-DD'),'YYYY')||'-01-01' and start_date<=to_char(last_day(to_date(a.acct_period,'yyyy-MM-DD')),'yyyy-MM-DD'))) year_sum_prvd_amt,
(select amount from syn_fl_contract_baseinfo where state<>0 and contract_id=d.contract_id and (start_date>=to_char(to_date(a.acct_period,'yyyy-MM-DD'),'YYYY-MM')||'-01' and start_date<=to_char(last_day(to_date(a.acct_period,'yyyy-MM-DD')),'yyyy-MM-DD'))) period_sum_prvd_amt,
(select sum(PRINCIPAL_AMOUNT) from syn_fl_returninst_detail where state=1 and contract_id=d.contract_id and (return_date>=to_char(to_date(a.acct_period,'yyyy-MM-DD'),'YYYY-MM')||'-01' and return_date<=to_char(last_day(to_date(a.acct_period,'yyyy-MM-DD')),'yyyy-MM-DD')) GROUP BY contract_id ) period_sum_repy_amt,
(SELECT sum(REMAIN_PRINCIPAL_BALANCE) FROM syn_fl_rentcal_result WHERE contract_id =d.contract_id and state=2 AND to_date(return_date,'YYYY-MM-DD')<=last_day(to_date(a.acct_period,'YYYY-MM-DD')) GROUP BY contract_id) as inst_bal
from ri_otherasset_result a,  syn_fl_contract_baseinfo d
where  a.asset_id=d.contract_no(+) and a.asset_org=d.org_code(+) and a.asset_type='10004'
) group by acct_period,cntt_org_code
) w1,
(
select t1.asset_type,t1.asset_org,t1.acct_period,t1.pre_period,t2.asset_balance pre_balance
from (
select a.asset_type,a.asset_org,a.acct_period, a.asset_balance,
(select max(acct_period) from RI_VIEW_CREDIT_SUM where acct_period<a.acct_period and asset_type=a.asset_type and asset_org=a.asset_org ) pre_period
from RI_VIEW_CREDIT_SUM a where a.asset_type='10004') t1,RI_VIEW_CREDIT_SUM t2
where t1.asset_type=t2.asset_type(+) and t1.asset_org=t2.asset_org(+) and t1.pre_period=t2.acct_period(+)
)w2
where w1.acct_period=w2.acct_period and w1.cntt_org_code=w2.asset_org
/

