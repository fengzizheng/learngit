CREATE VIEW RI_VIEW_LOAN_PRINTINFO AS
  select a.cntt_CODE,a.cntt_code as asset_id,a.acct_period,a.CNTT_org_CODE,b.type,B.SCORE,b.sort,b.sort_desc,b.intend_lost_rate, b.remark,b.oper_org,
(select org_name from ri_org_info where org_code=b.oper_org) as oper_org_name,
b.operator_id,
(select person_name from au_employee where id=b.operator_id) as operator,
b.oper_time,
b.report_person,
(select person_name from au_employee where id=b.report_person) as reportor,
b.report_time
 from ri_assetresult a,ri_assetsortdetail b
where a.sort_id=b.sort_id and a.state>=b.type
/

