CREATE VIEW RI_VIEW_LEASE_INFO AS
  select a1."CNTT_CODE",a1."LEASER",a1."CNTT_COST",a1."RATE",a1."LEASE_DATE",a1."PERIOD",a1."WARRANTY",a1."FEE",a1."GUARANTY_MODE",a1."CREDIT_FLAG",a1."MORTAGAGE_FLAG",a1."IMPAWN_FLAG",a1."PLEDGE_FLAG",a1."INVEST_STRU",a1."REMARK",a1."CUST_ID",a1."CUST_CODE",a1."IS_RATECHANGE",a1."IS_CNTTCHANGE",a1."IS_RETURN",a1."OP_DATE",a1."ORG_CODE",a1."INVT_CLS", a2.acct_period
  from ri_lease_info a1,
       (select cntt_code, acct_period, max(op_date) latest_date
          from (select t1.op_date, t1.cntt_code, t2.acct_period
                  from ri_lease_info t1, ri_otherasset_result t2
                 where t1.cntt_code = t2.asset_id
                   and t2.asset_type = '10004'
                   and to_date(t1.op_date, 'yyyy-mm-dd') <=
                       last_day(to_date(t2.acct_period, 'yyyy-mm-dd')))
         group by cntt_code, acct_period) a2
 where a1.cntt_code = a2.cntt_code
   and a1.op_date = a2.latest_date
/

