CREATE VIEW RI_VIEW_OTHER_PRINTINFO AS
  select a.asset_id,a.acct_period,a.asset_type,a.asset_org,b.type,b.sort,b.sort_desc,b.remark,b.oper_org,
(select org_name from ri_org_info where org_code=b.oper_org) as oper_org_name,
b.operator_id,
(select person_name from au_employee where id=b.operator_id) as operator,
b.oper_time,
b.report_person,
(select person_name from au_employee where id=b.report_person) as reportor,
b.report_time
 from ri_otherasset_result a,ri_otherasset_sortdetail b
where a.result_id=b.result_id and a.state>=b.type and asset_type='10005'
/

