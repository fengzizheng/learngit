CREATE VIEW RI_VIEW_PAPER_SORTDETAIL AS
  select r.rpt_id,r.asset_id,r.state,r.type,r.asset_org,r.org_name,r.acct_period,r.paper_type,r.asset_item,r.asset_item_sort,r.book_value,r.market_value,r.profit_loss,r.remark,
(select sort_value from ri_otherasset_paper_sortdetail where sort=1 and asset_id=r.asset_id and type=r.type and result_id = r.result_id ) as sort_1,
(select sort_value from ri_otherasset_paper_sortdetail where sort=2 and asset_id=r.asset_id and type=r.type and result_id = r.result_id) as sort_2,
(select sort_value from ri_otherasset_paper_sortdetail where sort=3 and asset_id=r.asset_id and type=r.type and result_id = r.result_id) as sort_3,
(select sort_value from ri_otherasset_paper_sortdetail where sort=4 and asset_id=r.asset_id and type=r.type and result_id = r.result_id) as sort_4,
(select sort_value from ri_otherasset_paper_sortdetail where sort=5 and asset_id=r.asset_id and type=r.type and result_id = r.result_id) as sort_5,
(select sum(sort_value) from ri_otherasset_paper_sortdetail
where sort>2
and asset_id=r.asset_id and type=r.type and result_id = r.result_id) as abnormal_balance
from (
select distinct a.result_id,a.rpt_id,a.asset_id,a.state,c.type,c.remark,a.asset_org,b.org_name,a.acct_period,a.paper_type,a.asset_item,a.asset_item_sort,a.book_value,a.market_value,a.profit_loss
from ri_otherasset_paper_result a,ri_org_info b,ri_otherasset_paper_sortdetail c
where a.asset_org=b.ORG_CODE and a.asset_id=c.asset_id and a.state>=c.type and a.result_id = c.result_id
) r
/

