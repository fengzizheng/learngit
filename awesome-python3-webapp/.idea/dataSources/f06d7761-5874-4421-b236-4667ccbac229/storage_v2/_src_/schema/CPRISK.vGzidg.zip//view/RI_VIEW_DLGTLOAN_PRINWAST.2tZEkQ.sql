CREATE VIEW RI_VIEW_DLGTLOAN_PRINWAST AS
  select a.cntt_code,a.org_code cntt_org_code,a.borrower_id,b.summery,b.change_amt,b.valid_date
from syn_ln_loan_cntt a,syn_ln_prin_waste_book b where a.cntt_code=b.cntt_code and a.prod_code='11' and a.state='4'and b.state='3'
/

