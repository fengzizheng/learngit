CREATE VIEW LN_SELF_INST_WASTE_BOOK AS
  SELECT A.ACCOUNTID SELF_INST_WASTE_BOOK_ID, --  自营贷款利息台账编号
       (select org_code from t_09_org where new_org_code=A.SUBORG) ORG_CODE, --  机构编号
       B.INTERENDDATE BIZ_DATE, --  业务日期
      (CASE WHEN A.BUSITYPE IN('001016002','001016','001016001') THEN '15'
 WHEN A.BUSITYPE IN ('001001','001001001','001001002','001001003','001001004','001002','001002001','001002002','001002003') THEN '10'
 WHEN A.BUSITYPE IN('002002001','001018') THEN '11' ELSE A.BUSITYPE END) PROD_CODE, -- 贷款品种编码
       C.CUSID BORROWER_ID, --  借款人编号
       A.CONTRACTNO CNTT_CODE, --  合同编码
       C.PERCONTRACTNO DFRD_CNTT_CODE, --  展期合同编码
       '' PRVD_INFM_CODE, -- 放款通知单编码
       '' REPAY_EXE_CODE, -- 还款执行计划编码
       '' INST_TYPE, --  利息种类
       decode(d.ABSTRACT,0,1,1,2,d.abstract) SUMMERY, --  摘要
       '' VOUCHER_CODE, --  凭证编码
       B.INTERACCO CALC_INST_AMT, --  计息金额
       B.RATEYEAR INST_RATE, --  利率
       B.INTERSTARTDATE INST_TERM_FROM, --  计息区间（起）
       B.INTERENDDATE INST_TERM_TO, --  计息区间（止）
       B.INTERSTARTDATE INST_TERM_FROM_FACT, --  计息实际起始日期
       B.INTERENDDATE INST_TERM_TO_FACT, --  计息实际终止日期
       B.INTERACCO SHOULD_RECEIVE_INST, --  应收利息
       B.INTEREST ALREADY_RECEIVE_INST, --  已收利息
       '' RECEIVE_INST_AMT, --  收取利息金额
       '' AHEAD_REPAY_FLAG, --  提前还款标志
       '' RUSH_FLAG, --  冲减标志
       '' RUSH_WASTE_BOOK_ID, --  冲减台帐编号
       '' RUSH_INST, --  冲减利息金额
       '' RECORD_DATE, --  记录业务时间
       '' AUDT_DATE, --  审核时间
       '' AUDITOR, --  审核人
       '' REMARK, --  备注
       '' HAND_FLAG, --  手工登记标志
       '3'/*a.contarctstatus*/ STATE, --  状态
       '' OPERATOR, --  记录人
       '' ADJUSTED_WASTE_BOOK_ID, --  调整后台帐编号
       '' AVERAGE_APPLY_CODE, --  卖断申请编号
       B.RATEMON INST_RATE_MONTH --  月利率
  FROM CRECAP_INTERBASE_INFO A,
       CREINTER_ACCO_INFO B,
       BUSI_CONTRACT_CORP C,
       CRECAP_ACCO_INFO d
 WHERE A.CONTRACTNO = C.CONTRACTNO
   AND A.ACCOUNTID = B.ACCOUNTID
   AND b.accountid=d.accountid(+)
   AND A.BUSITYPE IN('001001','001001001','001001002','001001003','001001004','001002','001002001','001002002','001002003','002002001','001018')
/

