CREATE VIEW RI_VIEW_CREDITRIGHT_DETAIL AS
  select d.result_id,d.state,d.sort,d.sort_desc,a.rpt_org,c.org_name,rpt_date, b.asset_id,b.CREDITRIGHT_TYPE,b.PROJECT_NAME,b.BALANCE ,d.acct_period,
(SELECT e.sort_desc FROM ri_otherasset_result e
wHERE e.acct_period =
                    TO_CHAR
                           (ADD_MONTHS (TO_DATE (d.acct_period, 'yyyy-MM-DD'),
                                        -1
                                       ),
                            'yyyy-MM-DD'
                           )
             AND e.asset_id = d.asset_id) AS pre_sort
from ri_otherasset_rptinfo a,ri_otherasset_creditright b ,ri_org_info c,ri_otherasset_result d
where a.rpt_id=b.rpt_id and a.RPT_ORG=c.ORG_CODE and a.rpt_id=d.rpt_id and b.asset_id=d.asset_id
/

