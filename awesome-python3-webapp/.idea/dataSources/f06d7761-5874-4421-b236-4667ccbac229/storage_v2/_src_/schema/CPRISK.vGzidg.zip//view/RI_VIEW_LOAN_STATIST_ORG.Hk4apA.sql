CREATE VIEW RI_VIEW_LOAN_STATIST_ORG AS
  select term_cls,
       acct_period,
       cntt_org_code,
       count(cntt_code) num,
       sum(cntt_balance) cntt_balance,
       sum(pre_balance) pre_balance,
       sum(year_sum_prvd_amt) year_sum_prvd_amt,
       sum(period_sum_prvd_amt) period_sum_prvd_amt,
       sum(period_sum_repy_amt) period_sum_repy_amt,
       sum(period_sum_dfrd_amt) period_sum_dfrd_amt,
       sum(inst_bal) inst_bal
  from RI_VIEW_LOAN_STATIST
 group by term_cls, acct_period, cntt_org_code
/

