CREATE VIEW CR_CUSTBASEINFO1 AS
  select cust_id,NAME from ri_custbaseinfo
UNION ALL
select cust_id,cust_name NAME from ri_tradecustbase
/

