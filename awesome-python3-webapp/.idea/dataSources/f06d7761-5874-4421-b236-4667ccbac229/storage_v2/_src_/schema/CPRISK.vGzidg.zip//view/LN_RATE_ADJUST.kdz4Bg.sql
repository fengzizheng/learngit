CREATE VIEW LN_RATE_ADJUST AS
  SELECT
a.applyno RATE_ADJT_ID ,-- 贷款利率调整编号
(select org_code from t_09_org where new_org_code=a.inputorgid) ORG_CODE ,--  办理机构编号
b.cusid BORROWER_ID,--   借款人编号
c.contractno CNTT_CODE,--   合同编码
'' PRVD_INFM_CODE ,--  放款通知单编码
'' REPAY_EXE_CODE ,--  还款执行计划编码
a.newcontex NEW_RATE ,--  新利率（月）
a.execdate START_DATE ,--  新利率起息日
a.remark ADJT_REASON ,--  利率调整原因
a.chgdate ADJT_TIME ,--  调整时间
a.inputuserid OPERATOR_ID ,--  操作员
'' AUDIT_TIME ,--  审批时间
'' AUDITOR_ID,--   审批人
decode(a.currstatus,0,3,a.currstatus) STATE ,--  状态
'' at_term_state ,--  是否展期逾期状态
'' new_rate_MONTH  -- 月利率
FROM
BUSI_CONTRACT_VARDTL a,
BUSI_CONTRACT_CORP b,
BUSI_CONTRACT_VARIATION c
WHERE a.applyno=c.applyno
AND c.contractno=b.contractno
AND a.currstatus='0'
/

