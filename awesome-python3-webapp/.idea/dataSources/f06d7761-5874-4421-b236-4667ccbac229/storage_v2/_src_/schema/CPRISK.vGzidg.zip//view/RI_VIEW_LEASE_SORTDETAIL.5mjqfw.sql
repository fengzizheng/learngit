CREATE VIEW RI_VIEW_LEASE_SORTDETAIL AS
  select a.result_id,a.rpt_id,a.asset_id, c.type,a.state,a.acct_period,a.asset_org,b.org_name,c.asset_balance,c.sort,c.sort_desc,c.remark,
d.leaser,d.cntt_code,d.cntt_amt,d.balance_prin,d.balance_inst,d.lease_amt,d.rate,d.lease_date,d.period,d.warranty,d.fee,d.guaranty_mode,d.invest_stru,
decode(c.sort,1,c.asset_balance,2,c.asset_balance,3,c.asset_balance,'') as sort_1,
decode(c.sort,4,c.asset_balance,5,c.asset_balance,6,c.asset_balance,'') as sort_2,
decode(c.sort,7,c.asset_balance,8,c.asset_balance,'') as sort_3,
decode(c.sort,9,c.asset_balance,'') as sort_4,
decode(c.sort,10,c.asset_balance,'') as sort_5,
        (SELECT e.sort_desc
            FROM ri_otherasset_result e
           WHERE e.asset_id = a.asset_id and e.asset_org=a.asset_org
           and e.acct_period in(select max(acct_period) from ri_otherasset_result where asset_id = a.asset_id and asset_org=a.asset_org and acct_period<a.acct_period)
         ) AS pre_sort,
(select sum(asset_balance) from RI_OTHERASSET_SORTDETAIL
where sort>6
and detail_id=c.detail_id ) as abnormal_balance
from ri_otherasset_result a,ri_org_info b,RI_OTHERASSET_SORTDETAIL c,RI_OTHERASSET_lease d
where a.asset_org=b.ORG_CODE
and a.ASSET_TYPE='10004'
and a.asset_id=d.asset_id and a.rpt_id=d.rpt_id
and a.result_id=c.result_id and a.state>=c.type
/

