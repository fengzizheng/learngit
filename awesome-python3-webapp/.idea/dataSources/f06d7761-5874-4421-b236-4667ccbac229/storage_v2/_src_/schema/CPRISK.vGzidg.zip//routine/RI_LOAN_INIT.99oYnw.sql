CREATE procedure ri_loan_init(p_date in varchar2) is

 p_org_code  ri_loan_baseinfo.org_code%type;

 p_cntt_code  ri_loan_baseinfo.cntt_code%type;
 cntt_num Integer;
 dfrd_num Integer;
 adjust_num Integer;
 gua_num Integer;
 instwb_num Integer;
 prinwb_num Integer;
 repayplan_num Integer;
 prvdexe_num Integer;
 --curr_num Integer;


  old_dfrd_num Integer;
  old_adjust_num Integer;
  old_gua_num Integer;
  old_instwb_num Integer;
  old_prinwb_num Integer;
  old_repayplan_num Integer;
  old_prvdexe_num Integer;


 --?????????????
 cursor normal_rs(l_date in varchar2)is
        select distinct org_code,cntt_code from ln_loan_cntt where cntt_code in
        (
          select cntt_code from ln_prin_waste_book where valid_date<l_date and  state='3'
          union
          select cntt_code from Ln_self_inst_waste_book where biz_date<l_date and state='3' and summery in ('1','2')
        )
        and prod_code in ('10','14','15') and state in ('4','6');

begin

 open normal_rs(p_date);
  loop
    fetch normal_rs into p_org_code,p_cntt_code;
    EXIT WHEN normal_rs%NOTFOUND;

  /*  select count(*) into curr_num from org_currt_relation t where t.biz_org_code='1099'
    and t.org_code <> '1099' and t.org_code=p_org_code;

    if curr_num >0  --机构号为外币机构号
       then*/
          --??????
              select count(*) into cntt_num from ri_loan_baseinfo where cntt_code=p_cntt_code;
            if cntt_num>0
            then
                delete from ri_loan_baseinfo where cntt_code=p_cntt_code;
                commit;
            end if;

    insert into ri_loan_baseinfo
    (CNTT_ID,CNTT_CODE,YEAR,ORG_CODE,          ORG_NAME,BORROWER_ID,          BORROWER_NAME,PROD_CODE, IS_STANDARD,LOAN_AMT,INST_RATE,APPROP_RATE,OVERDUE_RATE,USAGE,START_DATE,END_DATE,INST_PAY_TYPE,REPAY_SOURCE, SUPPLEMENT, SIGN_DATE, LOAN_TERM, INVT_CLS, INVT_SUB_CLS, TERM_CLS, USAGE_CLS, USAGE_SUB_CLS, CREDIT_FLAG, MORTAGAGE_FLAG, IMPAWN_FLAG, PLEDGE_FLAG, SELLED_FLAG, CAL_INST_TYPE,spare1,cycle_flag,repay_source_type,assure_type,own_org_code,own_org_type,currency)
    select
     CNTT_ID,CNTT_CODE,YEAR,T.ORG_CODE as ORG_CODE,a.org_name as ORG_NAME,BORROWER_ID,b.name as BORROWER_NAME,PROD_CODE, IS_STANDARD,LOAN_AMT,INST_RATE,APPROP_RATE,OVERDUE_RATE,USAGE,START_DATE,END_DATE,INST_PAY_TYPE,REPAY_SOURCE, SUPPLEMENT, SIGN_DATE, LOAN_TERM, INVT_CLS, INVT_SUB_CLS, TERM_CLS, USAGE_CLS, USAGE_SUB_CLS, CREDIT_FLAG, MORTAGAGE_FLAG, IMPAWN_FLAG, PLEDGE_FLAG, SELLED_FLAG, CAL_INST_TYPE,spare1,cycle_flag,repay_source_type,assure_type,own_org_code,own_org_type,t.org_code
    from ln_loan_cntt t,t_09_org a,cr_custbaseinfo1 b
    where t.cntt_code=p_cntt_code and t.org_code=a.org_code and t.borrower_id=b.cust_id;
    commit;

     --????
     select count(*) into old_gua_num from ln_guaranty_desc where  guaranty_grp_id=p_cntt_code;
     if
     old_gua_num>0
     then

      select count(*) into gua_num from ri_loan_guarantyinfo where  guaranty_grp_id=p_cntt_code;
            if gua_num>0
            then
                delete from ri_loan_guarantyinfo where  guaranty_grp_id=p_cntt_code;
                 commit;
            end if;

     insert into ri_loan_guarantyinfo
     (GUARANTY_ID, GUARANTY_GRP_ID,           WARRANTOR_ID,WARRANTOR_NAME, GUARANTY_MODE, GUARANTY_TYPE, GUARANTY_NAME, GUARANTY_VALUE, GUARANTY_RATE, GUARANTY_AMT,ASSURANCE_TERM, STORE_PLACE,FSCL_YEAR,REMARK, SPARE2, SPARE3)
     select
      GUARANTY_ID, GUARANTY_GRP_ID, SPARE1 as WARRANTOR_ID,WARRANTOR_NAME, GUARANTY_MODE, GUARANTY_TYPE, GUARANTY_NAME, GUARANTY_VALUE, GUARANTY_RATE, GUARANTY_AMT,ASSURANCE_TERM, STORE_PLACE,FSCL_YEAR, REMARK, SPARE2, SPARE3
     from ln_guaranty_desc t
     where  t.guaranty_grp_id=p_cntt_code;
     commit;
     end if;

    --??????
    select count(*) into old_prinwb_num from ln_prin_waste_book where cntt_code=p_cntt_code and (prod_code='10' or prod_code='14') and state='3';
     if old_prinwb_num>0
     then

     select count(*) into prinwb_num from ri_loan_prinwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
            if prinwb_num>0
            then
                delete from ri_loan_prinwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
            commit;
            end if;

      insert into ri_loan_prinwastebook
     (  PRIN_WASTE_BOOK_ID, ORG_CODE,           ORG_NAME,PROD_CODE, CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, REMARK,VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, RETURNED_FLAG,SPARE1, SPARE2,SPARE3,repay_date)
     select
      t.PRIN_WASTE_BOOK_ID, t.org_code as ORG_CODE, a.org_name as ORG_NAME,t.PROD_CODE, t.CNTT_CODE,t.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_CODE,t.SUMMERY, t.CHANGE_AMT, t.RECORD_DATE,t.RECORDER, t.REMARK,t.VALID_DATE, t.VOUCHER_CODE, t.DFRD_FLAG,t.AHEAD_REPAY_FLAG,t.HAND_FLAG, t.RETURNED_FLAG,t.SPARE1, t.SPARE2,t.SPARE3,r.REPAY_DATE
     from ln_prin_waste_book t, t_09_org a, Ln_Prvd_Exe r
     where  t.state=3 and t.cntt_code=p_cntt_code and t.org_code=a.org_code and t.cntt_code=r.cntt_code;
      commit;
      end if;

    --??????
    select count(*) into old_prinwb_num from ln_joiner_prin_waste_book p WHERE cntt_code=p_cntt_code and prod_code='15' and state='3';
     if old_prinwb_num>0
     then

     select count(*) into prinwb_num from ri_loan_prinwastebook where  cntt_code=p_cntt_code and prod_code='15';
            if prinwb_num>0
            then
                delete from ri_loan_prinwastebook where  cntt_code=p_cntt_code and prod_code='15';
            commit;
            end if;

      insert into ri_loan_prinwastebook
     (PRIN_WASTE_BOOK_ID, ORG_CODE,           ORG_NAME,PROD_CODE, CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, repay_date)
     select
      t.prin_waste_book_id as PRIN_WASTE_BOOK_ID, t.joiner_id as org_code, a.org_name as ORG_NAME,t.PROD_CODE, t.CNTT_CODE,p.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_plan,t.SUMMERY, t.amount as CHANGE_AMT, t.record_time as RECORD_DATE,t.recorder_id as RECORDER, t.VALID_DATE, t.VOUCHER_CODE, p.DFRD_FLAG,p.AHEAD_REPAY_FLAG, p.HAND_FLAG, r.REPAY_DATE
     from ln_joiner_prin_waste_book t, t_09_org a,Ln_Prvd_Exe r,ln_prin_waste_book p
     where t.joiner_id=a.org_code and t.cntt_code=p_cntt_code  and t.cntt_code=r.cntt_code
      and p.prin_waste_book_id=t.prin_waste_book_id and t.prod_code='15' and p.state='3';
      commit;
      end if;


    --??????
    select count(*) into old_instwb_num from ln_self_inst_waste_book where cntt_code=p_cntt_code and (prod_code='10' or prod_code='14') and state='3' and summery in ('1','2');
     if old_instwb_num>0
     then

    select count(*) into instwb_num from ri_loan_instwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
            if instwb_num>0
            then
                delete from ri_loan_instwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
             commit;
            end if;

     insert into ri_loan_instwastebook
     (    INST_WASTE_BOOK_ID, ORG_CODE,          ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG, RUSH_FLAG, RUSH_WASTE_BOOK_ID,RUSH_INST, RECORD_DATE, REMARK,HAND_FLAG, ADJUSTED_WASTE_BOOK_ID)
     select
     SELF_INST_WASTE_BOOK_ID,t.org_code as ORG_CODE,a.org_name as ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG, RUSH_FLAG, RUSH_WASTE_BOOK_ID,RUSH_INST, RECORD_DATE, t.REMARK,HAND_FLAG, ADJUSTED_WASTE_BOOK_ID
     from ln_self_inst_waste_book t, t_09_org a
     where  t.cntt_code=p_cntt_code and t.org_code=a.org_code and t.state='3' and t.summery in ('1','2');
      commit;
      end if;

    --??????
    select count(*) into old_instwb_num from ln_joiner_inst_waste_book s WHERE  cntt_code=p_cntt_code and prod_code='15' and state='3' and summery in ('1','2');
     if old_instwb_num>0
     then

    select count(*) into instwb_num from ri_loan_instwastebook where  cntt_code=p_cntt_code and prod_code='15';
            if instwb_num>0
            then
                delete from ri_loan_instwastebook where  cntt_code=p_cntt_code and prod_code='15';
             commit;
            end if;

     insert into ri_loan_instwastebook
     (    INST_WASTE_BOOK_ID, ORG_CODE,          ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG,  RECORD_DATE, HAND_FLAG)
     select
     joiner_INST_WASTE_BOOK_ID as INST_WASTE_BOOK_ID, t.joiner_id as ORG_CODE,a.org_name as ORG_NAME,t.valid_date as BIZ_DATE,t.PROD_CODE,t.CNTT_CODE,p.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_plan,p.INST_TYPE,t.SUMMERY, t.VOUCHER_CODE,t.CAL_INST_amount, p.INST_RATE, p.INST_TERM_FROM,p.INST_TERM_TO, p.INST_TERM_FROM_FACT, p.INST_TERM_TO_FACT,t.should_receive_amount as SHOULD_RECEIVE_INST, t.already_receive_amount as ALREADY_RECEIVE_INST,t.RECEIVE_INST_amount,p.AHEAD_REPAY_FLAG,  t.record_time as RECORD_DATE, p.HAND_FLAG
     from ln_joiner_inst_waste_book t, t_09_org a,ln_self_inst_waste_book p
     where t.cntt_code=p_cntt_code and t.joiner_id=a.org_code  and t.prod_code='15' and t.inst_waste_book_id=p.self_inst_waste_book_id
     and t.state='3' and t.summery in ('1','2')  ;
      commit;
      end if;

     --????
    select count(*) into old_dfrd_num from LN_DFRD_CNTT where cntt_code =p_cntt_code ;
    if old_dfrd_num>0
    then

     select count(*) into dfrd_num from ri_loan_dfrdcntt where cntt_code =p_cntt_code ;
            if dfrd_num>0
            then
                 delete from ri_loan_dfrdcntt where cntt_code =p_cntt_code ;
                  commit;
            end if;

    insert into ri_loan_dfrdcntt
    (DFRD_CNTT_ID, DFRD_CNTT_CODE, YEAR,CNTT_CODE, PRVD_INFM_CODE,PRE_REPAY_EXE_CODE, PROD_CODE, ORG_CODE,TO_DATE_AMT, DFRD_AMT, DFRD_RATE,DFRD_REASON, SIGN_DATE, PROVINCE,CITY, IS_STANDARD, SUPPLEMENT,CNTT_MGR, OPER_TIME, START_DATE, END_DATE, DFRD_TERM)
    select
     DFRD_CNTT_ID, DFRD_CNTT_CODE, YEAR,CNTT_CODE, PRVD_INFM_CODE,PRE_REPAY_EXE_CODE, PROD_CODE, l.org_code as ORG_CODE,TO_DATE_AMT, DFRD_AMT, DFRD_RATE,DFRD_REASON, SIGN_DATE, PROVINCE,CITY, IS_STANDARD, SUPPLEMENT,CNTT_MGR, OPER_TIME, START_DATE, END_DATE, DFRD_TERM
    from LN_DFRD_CNTT l
    where cntt_code =p_cntt_code ;
    commit;
    end if;
    --????
    select count(*) into old_repayplan_num from Ln_Repay_Plan where cntt_code =p_cntt_code ;
    if old_repayplan_num>0
    then

     select count(*) into repayplan_num from ri_loan_repayplan where cntt_code =p_cntt_code ;
            if repayplan_num>0
            then
                 delete from ri_loan_repayplan where cntt_code =p_cntt_code ;
                  commit;
            end if;

    insert into ri_loan_repayplan
    (REPAY_EXE_CODE, PRVD_EXE_PLAN_CODE, PRE_REPAY_EXE_CODE,CNTT_CODE, PRVD_INFM_CODE, REPAY_DATE,REPAY_AMT, AT_TERM_STATE, SPARE1,SPARE2)
    select
     REPAY_EXE_CODE, PRVD_EXE_PLAN_CODE, PRE_REPAY_EXE_CODE,CNTT_CODE, PRVD_INFM_CODE, REPAY_DATE,REPAY_AMT, AT_TERM_STATE, SPARE1,SPARE2
    from Ln_Repay_Plan
    where cntt_code =p_cntt_code ;
    commit;
    end if;
    --????
    select count(*) into old_prvdexe_num from Ln_Prvd_Exe where cntt_code =p_cntt_code ;
    if old_prvdexe_num>0
    then

     select count(*) into prvdexe_num from ri_loan_prvdexe where cntt_code =p_cntt_code ;
            if prvdexe_num>0
            then
                 delete from ri_loan_prvdexe where cntt_code =p_cntt_code ;
                  commit;
            end if;

    insert into ri_loan_prvdexe
    (PRVD_EXE_CODE, CNTT_CODE, PRVD_DATE, PRVD_AMT, FINAL_REPAY_DATE, SPARE1, SPARE2)
    select
     PRVD_EXE_CODE, CNTT_CODE, PRVD_DATE, PRVD_AMT, REPAY_DATE, SPARE1, SPARE2
    from Ln_Prvd_Exe
    where cntt_code =p_cntt_code ;
    commit;
    end if;
    --??????
    select count(*) into old_adjust_num from LN_RATE_ADJUST where  cntt_code=p_cntt_code;
     if old_adjust_num>0
     then

     select count(*) into adjust_num from ri_loan_rateadjust where  cntt_code=p_cntt_code;
            if adjust_num>0
            then
                delete from ri_loan_rateadjust where  cntt_code=p_cntt_code;
                commit;
            end if;


     insert into ri_loan_rateadjust
     (RATE_ADJT_ID,     ORG_CODE,           ORG_NAME,CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,  NEW_RATE, START_DATE, ADJT_REASON, ADJT_TIME)
     select
     RATE_ADJT_ID, t.org_code as ORG_CODE, a.org_name as org_name,CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,  NEW_RATE, START_DATE, ADJT_REASON, ADJT_TIME
     from LN_RATE_ADJUST t, t_09_org a
     where  t.cntt_code=p_cntt_code and t.org_code=a.org_name ;
     commit;
      end if;
/*   else --不是外币机构
         --??????
            select count(*) into cntt_num from ri_loan_baseinfo where cntt_code=p_cntt_code;
            if cntt_num>0
            then
                delete from ri_loan_baseinfo where cntt_code=p_cntt_code;
                commit;
            end if;

    insert into ri_loan_baseinfo
    (CNTT_ID,CNTT_CODE,YEAR,ORG_CODE,          ORG_NAME,BORROWER_ID,          BORROWER_NAME,PROD_CODE, IS_STANDARD,LOAN_AMT,INST_RATE,APPROP_RATE,OVERDUE_RATE,USAGE,START_DATE,END_DATE,INST_PAY_TYPE,REPAY_SOURCE, SUPPLEMENT, SIGN_DATE, LOAN_TERM, INVT_CLS, INVT_SUB_CLS, TERM_CLS, USAGE_CLS, USAGE_SUB_CLS, CREDIT_FLAG, MORTAGAGE_FLAG, IMPAWN_FLAG, PLEDGE_FLAG, SELLED_FLAG, CAL_INST_TYPE,spare1,cycle_flag,repay_source_type,assure_type,own_org_code,own_org_type,currency)
    select
     CNTT_ID,CNTT_CODE,YEAR,ORG_CODE,a.name as ORG_NAME,BORROWER_ID,b.name as BORROWER_NAME,PROD_CODE, IS_STANDARD,LOAN_AMT,INST_RATE,APPROP_RATE,OVERDUE_RATE,USAGE,START_DATE,END_DATE,INST_PAY_TYPE,REPAY_SOURCE, SUPPLEMENT, SIGN_DATE, LOAN_TERM, INVT_CLS, INVT_SUB_CLS, TERM_CLS, USAGE_CLS, USAGE_SUB_CLS, CREDIT_FLAG, MORTAGAGE_FLAG, IMPAWN_FLAG, PLEDGE_FLAG, SELLED_FLAG, CAL_INST_TYPE,spare1,cycle_flag,repay_source_type,assure_type,own_org_code,own_org_type,'00'
    from ln_loan_cntt t,gap_org_party a,cr_custbaseinfo b
    where t.cntt_code=p_cntt_code and t.org_code=a.coding and t.borrower_id=b.cust_id and a.status='0';
    commit;


     --????
     select count(*) into old_gua_num from ln_guaranty_desc where  guaranty_grp_id=p_cntt_code;
     if
     old_gua_num>0
     then

      select count(*) into gua_num from ri_loan_guarantyinfo where  guaranty_grp_id=p_cntt_code;
            if gua_num>0
            then
                delete from ri_loan_guarantyinfo where  guaranty_grp_id=p_cntt_code;
                 commit;
            end if;

     insert into ri_loan_guarantyinfo
     (GUARANTY_ID, GUARANTY_GRP_ID,           WARRANTOR_ID,WARRANTOR_NAME, GUARANTY_MODE, GUARANTY_TYPE, GUARANTY_NAME, GUARANTY_VALUE, GUARANTY_RATE, GUARANTY_AMT,ASSURANCE_TERM, STORE_PLACE,FSCL_YEAR,REMARK, SPARE2, SPARE3)
     select
      GUARANTY_ID, GUARANTY_GRP_ID, SPARE1 as WARRANTOR_ID,WARRANTOR_NAME, GUARANTY_MODE, GUARANTY_TYPE, GUARANTY_NAME, GUARANTY_VALUE, GUARANTY_RATE, GUARANTY_AMT,ASSURANCE_TERM, STORE_PLACE,FSCL_YEAR, REMARK, SPARE2, SPARE3
     from ln_guaranty_desc t
     where  t.guaranty_grp_id=p_cntt_code;
     commit;
     end if;

    --??????
    select count(*) into old_prinwb_num from ln_prin_waste_book where cntt_code=p_cntt_code and (prod_code='10' or prod_code='14') and state='3';
     if old_prinwb_num>0
     then

     select count(*) into prinwb_num from ri_loan_prinwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
            if prinwb_num>0
            then
                delete from ri_loan_prinwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
            commit;
            end if;

      insert into ri_loan_prinwastebook
     (  PRIN_WASTE_BOOK_ID, ORG_CODE,           ORG_NAME,PROD_CODE, CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, REMARK,VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, RETURNED_FLAG,SPARE1, SPARE2,SPARE3,repay_date)
     select
      t.PRIN_WASTE_BOOK_ID, ORG_CODE, a.name as ORG_NAME,t.PROD_CODE, t.CNTT_CODE,t.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_CODE,t.SUMMERY, t.CHANGE_AMT, t.RECORD_DATE,t.RECORDER, t.REMARK,t.VALID_DATE, t.VOUCHER_CODE, t.DFRD_FLAG,t.AHEAD_REPAY_FLAG,t.HAND_FLAG, t.RETURNED_FLAG,t.SPARE1, t.SPARE2,t.SPARE3,r.repay_date
     from ln_prin_waste_book t, gap_org_party a, ln_repay_plan r
     where  t.state=3 and t.cntt_code=p_cntt_code and t.org_code=a.coding and a.status='0' and t.repay_exe_code=r.repay_exe_code ;
      commit;
      end if;

    --??????
    select count(*) into old_prinwb_num from ln_joiner_prin_waste_book p,gap_org_party g where p.joiner_id=g.party_id and cntt_code=p_cntt_code and prod_code='15' and state='3';
     if old_prinwb_num>0
     then

     select count(*) into prinwb_num from ri_loan_prinwastebook where  cntt_code=p_cntt_code and prod_code='15';
            if prinwb_num>0
            then
                delete from ri_loan_prinwastebook where  cntt_code=p_cntt_code and prod_code='15';
            commit;
            end if;

      insert into ri_loan_prinwastebook
     (PRIN_WASTE_BOOK_ID, ORG_CODE,           ORG_NAME,PROD_CODE, CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,SUMMERY, CHANGE_AMT, RECORD_DATE,RECORDER, VALID_DATE, VOUCHER_CODE, DFRD_FLAG,AHEAD_REPAY_FLAG, HAND_FLAG, repay_date)
     select
      joiner_prin_WASTE_BOOK_ID as PRIN_WASTE_BOOK_ID, a.coding as org_code, a.name as ORG_NAME,t.PROD_CODE, t.CNTT_CODE,p.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_plan,t.SUMMERY, t.amount as CHANGE_AMT, t.record_time as RECORD_DATE,t.recorder_id as RECORDER, t.VALID_DATE, t.VOUCHER_CODE, p.DFRD_FLAG,p.AHEAD_REPAY_FLAG, p.HAND_FLAG, r.repay_date
     from ln_joiner_prin_waste_book t, gap_org_party a,ln_repay_plan r,ln_prin_waste_book p
     where t.joiner_id=a.party_id and t.cntt_code=p_cntt_code and a.status='0' and t.repay_exe_plan=r.repay_exe_code and p.prin_waste_book_id=t.prin_waste_book_id and t.prod_code='15' and p.state='3';
      commit;
      end if;


    --??????
    select count(*) into old_instwb_num from ln_self_inst_waste_book where cntt_code=p_cntt_code and (prod_code='10' or prod_code='14') and state='3' and summery in ('1','2');
     if old_instwb_num>0
     then

    select count(*) into instwb_num from ri_loan_instwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
            if instwb_num>0
            then
                delete from ri_loan_instwastebook where  cntt_code=p_cntt_code and (prod_code='10' or prod_code='14');
             commit;
            end if;

     insert into ri_loan_instwastebook
     (    INST_WASTE_BOOK_ID, ORG_CODE,          ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG, RUSH_FLAG, RUSH_WASTE_BOOK_ID,RUSH_INST, RECORD_DATE, REMARK,HAND_FLAG, ADJUSTED_WASTE_BOOK_ID)
     select
     SELF_INST_WASTE_BOOK_ID, ORG_CODE,a.name as ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG, RUSH_FLAG, RUSH_WASTE_BOOK_ID,RUSH_INST, RECORD_DATE, REMARK,HAND_FLAG, ADJUSTED_WASTE_BOOK_ID
     from ln_self_inst_waste_book t, gap_org_party a
     where  t.cntt_code=p_cntt_code and t.org_code=a.coding and a.status='0' and t.state='3' and t.summery in ('1','2');
      commit;
      end if;

    --??????
    select count(*) into old_instwb_num from ln_joiner_inst_waste_book s,gap_org_party g where s.joiner_id=g.party_id and cntt_code=p_cntt_code and prod_code='15' and state='3' and summery in ('1','2');
     if old_instwb_num>0
     then

    select count(*) into instwb_num from ri_loan_instwastebook where  cntt_code=p_cntt_code and prod_code='15';
            if instwb_num>0
            then
                delete from ri_loan_instwastebook where  cntt_code=p_cntt_code and prod_code='15';
             commit;
            end if;

     insert into ri_loan_instwastebook
     (    INST_WASTE_BOOK_ID, ORG_CODE,          ORG_NAME,BIZ_DATE,PROD_CODE,CNTT_CODE,DFRD_CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,INST_TYPE,SUMMERY, VOUCHER_CODE,CALC_INST_AMT, INST_RATE, INST_TERM_FROM,INST_TERM_TO, INST_TERM_FROM_FACT, INST_TERM_TO_FACT,SHOULD_RECEIVE_INST, ALREADY_RECEIVE_INST, RECEIVE_INST_AMT,AHEAD_REPAY_FLAG,  RECORD_DATE, HAND_FLAG)
     select
     joiner_INST_WASTE_BOOK_ID as INST_WASTE_BOOK_ID, a.coding as ORG_CODE,a.name as ORG_NAME,t.valid_date as BIZ_DATE,t.PROD_CODE,t.CNTT_CODE,p.DFRD_CNTT_CODE, t.PRVD_INFM_CODE, t.REPAY_EXE_plan,p.INST_TYPE,t.SUMMERY, t.VOUCHER_CODE,t.CAL_INST_amount, p.INST_RATE, p.INST_TERM_FROM,p.INST_TERM_TO, p.INST_TERM_FROM_FACT, p.INST_TERM_TO_FACT,t.should_receive_amount as SHOULD_RECEIVE_INST, t.already_receive_amount as ALREADY_RECEIVE_INST,t.RECEIVE_INST_amount,p.AHEAD_REPAY_FLAG,  t.record_time as RECORD_DATE, p.HAND_FLAG
     from ln_joiner_inst_waste_book t, gap_org_party a,ln_self_inst_waste_book p
     where t.cntt_code=p_cntt_code and t.joiner_id=a.party_id and a.status='0' and t.prod_code='15' and t.inst_waste_book_id=p.self_inst_waste_book_id
     and t.state='3' and t.summery in ('1','2');
      commit;
      end if;

     --????
    select count(*) into old_dfrd_num from LN_DFRD_CNTT where cntt_code =p_cntt_code ;
    if old_dfrd_num>0
    then

     select count(*) into dfrd_num from ri_loan_dfrdcntt where cntt_code =p_cntt_code ;
            if dfrd_num>0
            then
                 delete from ri_loan_dfrdcntt where cntt_code =p_cntt_code ;
                  commit;
            end if;

    insert into ri_loan_dfrdcntt
    (DFRD_CNTT_ID, DFRD_CNTT_CODE, YEAR,CNTT_CODE, PRVD_INFM_CODE,PRE_REPAY_EXE_CODE, PROD_CODE, ORG_CODE,TO_DATE_AMT, DFRD_AMT, DFRD_RATE,DFRD_REASON, SIGN_DATE, PROVINCE,CITY, IS_STANDARD, SUPPLEMENT,CNTT_MGR, OPER_TIME, START_DATE, END_DATE, DFRD_TERM)
    select
     DFRD_CNTT_ID, DFRD_CNTT_CODE, YEAR,CNTT_CODE, PRVD_INFM_CODE,PRE_REPAY_EXE_CODE, PROD_CODE, ORG_CODE,TO_DATE_AMT, DFRD_AMT, DFRD_RATE,DFRD_REASON, SIGN_DATE, PROVINCE,CITY, IS_STANDARD, SUPPLEMENT,CNTT_MGR, OPER_TIME, START_DATE, END_DATE, DFRD_TERM
    from LN_DFRD_CNTT
    where cntt_code =p_cntt_code ;
    commit;
    end if;
    --????
    select count(*) into old_repayplan_num from Ln_Repay_Plan where cntt_code =p_cntt_code ;
    if old_repayplan_num>0
    then

     select count(*) into repayplan_num from ri_loan_repayplan where cntt_code =p_cntt_code ;
            if repayplan_num>0
            then
                 delete from ri_loan_repayplan where cntt_code =p_cntt_code ;
                  commit;
            end if;

    insert into ri_loan_repayplan
    (REPAY_EXE_CODE, PRVD_EXE_PLAN_CODE, PRE_REPAY_EXE_CODE,CNTT_CODE, PRVD_INFM_CODE, REPAY_DATE,REPAY_AMT, AT_TERM_STATE, SPARE1,SPARE2)
    select
     REPAY_EXE_CODE, PRVD_EXE_PLAN_CODE, PRE_REPAY_EXE_CODE,CNTT_CODE, PRVD_INFM_CODE, REPAY_DATE,REPAY_AMT, AT_TERM_STATE, SPARE1,SPARE2
    from Ln_Repay_Plan
    where cntt_code =p_cntt_code ;
    commit;
    end if;
    --????
    select count(*) into old_prvdexe_num from Ln_Prvd_Exe where cntt_code =p_cntt_code ;
    if old_prvdexe_num>0
    then

     select count(*) into prvdexe_num from ri_loan_prvdexe where cntt_code =p_cntt_code ;
            if prvdexe_num>0
            then
                 delete from ri_loan_prvdexe where cntt_code =p_cntt_code ;
                  commit;
            end if;

    insert into ri_loan_prvdexe
    (PRVD_EXE_CODE, CNTT_CODE, PRVD_DATE, PRVD_AMT, FINAL_REPAY_DATE, SPARE1, SPARE2)
    select
     PRVD_EXE_CODE, CNTT_CODE, PRVD_DATE, PRVD_AMT, FINAL_REPAY_DATE, SPARE1, SPARE2
    from Ln_Prvd_Exe
    where cntt_code =p_cntt_code ;
    commit;
    end if;
    --??????
    select count(*) into old_adjust_num from LN_RATE_ADJUST where  cntt_code=p_cntt_code;
     if old_adjust_num>0
     then

     select count(*) into adjust_num from ri_loan_rateadjust where  cntt_code=p_cntt_code;
            if adjust_num>0
            then
                delete from ri_loan_rateadjust where  cntt_code=p_cntt_code;
                commit;
            end if;


     insert into ri_loan_rateadjust
     (RATE_ADJT_ID,     ORG_CODE,           ORG_NAME,CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,  NEW_RATE, START_DATE, ADJT_REASON, ADJT_TIME)
     select
     RATE_ADJT_ID, ORG_CODE, a.name as org_name,CNTT_CODE, PRVD_INFM_CODE, REPAY_EXE_CODE,  NEW_RATE, START_DATE, ADJT_REASON, ADJT_TIME
     from LN_RATE_ADJUST t, gap_org_party a
     where  t.cntt_code=p_cntt_code and t.org_code=a.coding and a.status='0';
     commit;

     end if;
end if;*/


  end loop;
  close normal_rs;

end ri_loan_init;
--20100115 update
/

