CREATE VIEW RI_VIEW_FACTOR_SUBCM AS
  SELECT G.CNTT_CODE asset_id,G.ACCT_PERIOD,z.contractno,z.biz_date,z.amt,z.summry
from
(SELECT a.contractno, q.ID, loancode, amt, biz_date, subcontractid, summry
  FROM RI_FBUS_CTCTM a,
       RI_FBUS_SUBCM b,
       (SELECT e.id,
               e.loancode,
               e.loanamount AS amt,
               e.LOANDATE AS biz_date,
               e.SUBCONTRACTID,
               '1' AS summry
          FROM RI_FINT_LOANM e
         WHERE LOANFLAG = '2'
        UNION ALL
        SELECT k.id,
               k.loancode,
               -z.amt,
               z.biz_date,
               k.SUBCONTRACTID,
               '2' AS summery
          FROM (SELECT e.id, e.loancode, e.SUBCONTRACTID
                  FROM RI_FINT_LOANM e
                 WHERE LOANFLAG = '2') k,
               (SELECT f.id,
                       nvl(t_payamount, 0) +
                       nvl(currenttransoverdueamount, 0) AS amt,
                       to_date(substr(CREATEDATE, 1, 10), 'yyyy-mm-dd') AS biz_DATE
                  FROM RI_FINT_LOANH f
                 WHERE KKSTATE = '1') z
         WHERE k.id = z.id) q
 WHERE a.id = b.contractid
   AND b.id = q.SUBCONTRACTID) z,ri_factorassetresult G
   where z.contractno=g.cntt_code
/

