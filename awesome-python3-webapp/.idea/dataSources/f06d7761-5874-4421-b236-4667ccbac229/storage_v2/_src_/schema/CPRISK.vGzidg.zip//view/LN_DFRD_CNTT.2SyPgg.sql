CREATE VIEW LN_DFRD_CNTT AS
  SELECT A.CONTRACTNO DFRD_CNTT_ID, -- 展期合同编号
       A.CONTRACTTEXTNO DFRD_CNTT_CODE, -- 展期合同编码
       SUBSTR(A.STARTDATE, 1, 4) YEAR, --贷款年度
       a.percontractno CNTT_CODE, -- 原合同编码
       '' DFRD_APLY_CODE, -- 展期申请编码
       '' PRVD_INFM_CODE, -- 放款通知单编码
       '' PRE_REPAY_EXE_CODE, -- 原还款执行计划编码
        (CASE WHEN A.BUSITYPE IN('001016002','001016','001016001') THEN '15'
 WHEN A.BUSITYPE IN ('001001','001001001','001001002','001001003','001001004','001002','001002001','001002002','001002003') THEN '10'
 WHEN A.BUSITYPE IN('002002001','001018') THEN '11' ELSE A.BUSITYPE END) PROD_CODE, -- 业务品种
       (select org_code from t_09_org where new_org_code=A.OPERATEORGID) ORG_CODE, -- 办理机构编码
       '' TO_DATE_AMT, -- 原到期金额
       '' DFRD_AMT, -- 展期金额
       A.ANNUALRATE DFRD_RATE, -- 展期利率
       A.APPROVENO DFRD_COMPANY_AUDIT_CODE, -- 公司有权审批编号
       '' DFRD_APPROP_RATE, -- 挪用利率
       A.LATEPENALTY DFRD_OVERDUE_RATE, --  逾期利率
       '' DFRD_REASON, -- 展期原因
       '' SIGN_DATE, -- 签署日期
       '' PROVINCE, -- 签订地点（省）
       '' CITY, -- 签订地点（市）
       '' IS_STANDARD, --  是否标准合同
       '' SUPPLEMENT, -- 补充条款
       '' CNTT_MGR, --合同管理人
       '' OPER_TIME, -- 最后修改时间
       A.STARTDATE START_DATE, --  合同起始日期
       A.ENDDATE END_DATE, -- 合同结束日期
       decode(A.CURRSTATUS,0,4,2,6,4,0,a.CURRSTATUS) STATE, -- 合同状态
       '' NOW_AUDITOR, --当前审批人
       '' FINAL_AUDITOR, --最后审批人
       '' FINAL_AUDIT_TIME, -- 最后审批时间
       B.PER_TERMMONTH DFRD_TERM, -- 展期期限
       A.BUSINESSRATE DFRD_RATE_MONTH, -- 展期合同月利率
       '' DFRD_APPROP_RATE_MONTH, -- 展期合同挪用月利率
       A.LATEPENALTY DFRD_OVERDUE_RATE_MONTH --展期合同逾期月利率
  FROM BUSI_CONTRACT_CORP A,(SELECT DISTINCT applyno,Contractno,PER_TERMMONTH FROM BUSI_CONTRACT_CORP_CHANGE) B
 WHERE A.Contractno = B.Contractno
/

