CREATE VIEW RI_VIEW_DLGTLOAN_INSTWAST AS
  select a.cntt_code,a.org_code cntt_org_code,a.borrower_id,b.summery,b.should_receive_inst,b.already_receive_inst,b.biz_date valid_date  from syn_ln_loan_cntt a,syn_ln_dlgt_inst_waste_book b where a.cntt_code=b.cntt_code and a.prod_code='11' and a.state='4'and b.state='3'
/

