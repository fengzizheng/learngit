CREATE VIEW RI_VIEW_DISCOUNT_DETAIL AS
  select d.acct_period,a.rpt_org,c.org_name as rpt_org_name,b.RPT_ID, b.ASSET_ID,
   b.DISCOUNT_BILL_ID, b.DISCOUNT_APLY_CODE, b.BILL_TYPE,
   b.BILL_CODE, b.REMITTER, b.BORROWER_NAME,
   b.ACCEPTOR_NAME, b.BORN_DATE, b.DISCOUNT_DATE,
   b.FACT_END_DATE, b.BILL_AMT, b.DISCOUNT_RATE, d.state,d.sort,d.sort_desc,b.cust_code,b.cust_id
   from ri_otherasset_rptinfo a,ri_otherasset_discount b,ri_org_info c,ri_otherasset_result d
where  a.RPT_ID=b.rpt_id and a.rpt_org=c.org_code and a.rpt_id=d.rpt_id and b.asset_id=d.asset_id
/

