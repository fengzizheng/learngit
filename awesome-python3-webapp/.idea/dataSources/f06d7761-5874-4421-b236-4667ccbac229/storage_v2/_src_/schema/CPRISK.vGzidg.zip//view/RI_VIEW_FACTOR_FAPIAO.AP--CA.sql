CREATE VIEW RI_VIEW_FACTOR_FAPIAO AS
  SELECT
b.BUYERNAME,--购货方名称
FUBCONTRACTNO,--贸易合同号
VOUCHER_CODE,--发票编号
VOUCHER_AMOUNT,--发票票面金额
FACE_AMOUNT,--发票未付金额
RECE_AMOUNT,--应收账款
b.LOANPCNT,--融资比例
z.cntt_code asset_id,
z.acct_period
FROM RI_FBUS_CTCTM a,RI_FBUS_SUBCM b,RI_FINT_VOUCM c,RI_FACTORASSETRESULT z
WHERE a.id=b.contractid AND b.id=c.SUB_CONTRACT_ID and a.contractno=z.cntt_code
/

