CREATE VIEW RI_VIEW_FACTOR_CUST AS
  SELECT c.sort_id,
       c.cntt_code asset_id,
       c.acct_period,
       c.cust_id,
       a.SELLERNAME, -- 销货方名称
       k.ARTIFICIAL, --法人代表
      (CASE WHEN k.cust_type2 IS NOT NULL THEN decode(k.cust_type1,'1','国网系统客户','2','非国网系统客户','国网系统客户')||'-'||
 decode (k.cust_type2,'20001','电网公司','20002','发电公司','20003','产业公司','20004','科研教培单位','20005','其他','其他')
 ELSE decode(k.cust_type1,'1','国网系统客户','2','非国网系统客户','国网系统客户') END)             cust_type, --主营业务
       k.REG_CAPT --注册资本
  FROM ri_FBUS_CTCTM a, ri_custbaseinfo k, RI_FACTORASSETRESULT c
 WHERE a.sellerid = k.code
   and a.contractno = c.cntt_code
   and k.cust_id = c.cust_id
/

