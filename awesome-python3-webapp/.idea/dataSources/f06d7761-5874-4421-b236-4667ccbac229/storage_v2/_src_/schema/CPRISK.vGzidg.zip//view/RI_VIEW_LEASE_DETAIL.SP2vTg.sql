CREATE VIEW RI_VIEW_LEASE_DETAIL AS
  select a.rpt_date,
       d.acct_period,
       a.rpt_org,
       c.org_name as rpt_org_name,
       d.state,
       d.sort,
       d.sort_desc,
       b.rpt_id,
       b.asset_id,
       b.leaser,
       b.cust_id,
       b.cust_code,
       b.cntt_code,
       b.cntt_amt,
       b.balance_prin,
       b.balance_inst,
       b.lease_amt,
       b.rate,
       b.lease_date,
       b.period,
       b.warranty,
       b.fee,
       b.guaranty_mode,
       b.invest_stru,
       (select e.sort_desc
          from ri_otherasset_result e
         where e.acct_period =
               to_char(add_months(to_date(d.acct_period, 'yyyy-mm-dd'), -1),
                       'yyyy-mm-dd')
           and e.asset_id = d.asset_id) as pre_sort,
       (select max(last_day(to_date(d.acct_period, 'yyyy-mm-dd')) -
                   to_date(should_receive_date, 'yyyy-mm-dd'))
          from fin_tenancy_rent_income
         where state <> 0
           and rent_cntt_code = b.cntt_code
           and to_date(should_receive_date, 'yyyy-mm-dd') <=
               last_day(to_date(d.acct_period, 'yyyy-mm-dd'))
           and should_receive_date>'2011-01-20'
           and bal_check_time is null
         group by rent_cntt_code) overdue_dayes,
       (select sum(should_receive_amt)
          from fin_tenancy_rent_income
         where state <> 0
           and rent_cntt_code = b.cntt_code
           and to_date(should_receive_date, 'yyyy-mm-dd') <=
               last_day(to_date(d.acct_period, 'yyyy-mm-dd'))
           and should_receive_date>'2011-01-20'
           and bal_check_time is null
         group by rent_cntt_code) overdue_prin,
       (select sum(should_receive_inst_amt)
          from fin_tenancy_rent_income
         where state <> 0
           and rent_cntt_code = b.cntt_code
           and to_date(should_receive_date, 'yyyy-mm-dd') <=
               last_day(to_date(d.acct_period, 'yyyy-mm-dd'))
           and should_receive_date>'2011-01-20'
           and bal_check_time is null
         group by rent_cntt_code) overdue_inst,
         b.is_chg_cntt, --新增
         b.is_chg_tz,  --新增
         b.is_chg_rate,--新增
         b.remark --新增
  from ri_otherasset_rptinfo a,
       ri_otherasset_lease   b,
       ri_org_info           c,
       ri_otherasset_result  d
 where a.rpt_id = b.rpt_id
   and a.rpt_org = c.org_code
   and a.rpt_id = d.rpt_id
   and b.asset_id = d.asset_id
   and b.rpt_id = d.rpt_id
/

