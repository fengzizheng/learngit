CREATE VIEW RI_VIEW_LOAN_SORTRESULT AS
  select c.cust_id,
       c.name,
       c.cust_type1,
       c.cust_type1_desc,
       c.cust_type2,
       c.cust_type2_desc,
       c.cust_type3,
       d.loan_term,
       decode(d.cycle_flag, '1', 'cycle', d.term_cls) term_cls,
       d.invt_cls,
       (SELECT NAME
          FROM syn_ln_loan_stat_cls
         where LOAN_STAT_CLS_ID = d.term_cls) as term_desc,
       d.usage_cls,
       (SELECT NAME
          FROM syn_ln_loan_stat_cls
         where LOAN_STAT_CLS_ID = d.usage_cls) as usage_cls_desc,
       d.usage_sub_cls,
       (SELECT NAME
          FROM syn_ln_loan_stat_cls
         where LOAN_STAT_CLS_ID = d.usage_sub_cls) as usage_sub_desc,
       nvl((select CREDIT_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           d.CREDIT_FLAG) as CREDIT_FLAG,
       nvl((select MORTAGAGE_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           d.MORTAGAGE_FLAG) as MORTAGAGE_FLAG,
       nvl((select IMPAWN_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           d.IMPAWN_FLAG) as IMPAWN_FLAG,
       nvl((select PLEDGE_FLAG
             from syn_ln_cntt_change
            where state = 3
              and cntt_code = a.cntt_code
              and start_date =
                  (select max(start_date)
                     from syn_ln_cntt_change
                    where state = 3
                      and cntt_code = a.cntt_code
                      and to_date(start_date, 'yyyy-mm-dd') <=
                          last_day(to_date(a.acct_period, 'yyyy-mm-dd')))),
           d.PLEDGE_FLAG) as PLEDGE_FLAG,
       a.sort_id,
       a.cntt_code,
       a.cntt_balance,
       f.inst_bal,
       a.acct_period,
       a.cntt_org_code,
      -- SUBSTR(a.cntt_org_code, 0, 2) as parent_code,
       b.parent_code,
       b.org_name,
       a.state,
       /*(select sort from (select sort,sort_id,row_number() over(partition by sort_id order by type desc) zz from
ri_assetsortdetail ) where zz=1 and sort_id=a.sort_id) sort,*/
       g.sort sort,
       g.sort_desc,
       a.remark,
       decode(g.sort,1, a.cntt_balance,2, a.cntt_balance,3, a.cntt_balance, '') as sort_1,
       decode(g.sort,4, a.cntt_balance,5, a.cntt_balance,6,a.cntt_balance, '') as sort_2,
       decode(g.sort, 7, a.cntt_balance,8, a.cntt_balance, '') as sort_3,
       decode(g.sort, 9, a.cntt_balance, '') as sort_4,
       decode(g.sort,10, a.cntt_balance, '') as sort_5,
       e.pre_sort_desc as pre_sort,
       (select sum(cntt_balance)
          from ri_assetresult e,
          (select sort,sort_id,sort_desc from (select sort,sort_id,sort_desc,row_number() over(partition by sort_id order by type desc) zz from
ri_assetsortdetail ) where zz=1 ) r
         where r.sort>6
           and e.sort_id = a.sort_id and r.sort_id(+)=e.sort_id ) as abnormal_balance
  from ri_assetresult   a,
       ri_org_info      b,
       ri_custbaseinfo  c,
       ri_loan_baseinfo d,
       ri_asset_presort e,
       ri_loan_inst_overdue f,
       (select sort,sort_id,sort_desc from (select sort,sort_id,sort_desc,row_number() over(partition by sort_id order by type desc) zz from
ri_assetsortdetail ) where zz=1 ) g
 where a.cntt_org_code = b.ORG_CODE
   and a.cntt_code = d.cntt_code
   and d.borrower_id = c.cust_id
   and a.cntt_code=e.cntt_code(+) and a.acct_period=e.acct_period(+)
   and a.cntt_code=f.cntt_code(+) and a.acct_period=f.acct_period(+)
   and g.sort_id(+)=a.sort_id
/

