CREATE procedure au_test_test
as
begin
  update au_test set visitor_type='3'
  where id in
  ( select id from (select * from au_test where visitor_type='2'));
  commit;
end;
/

