CREATE VIEW SYN_CR_CUSTBASEINFO AS
  SELECT

  cm.CUST_ID                AS cust_id          -- 客户主键 as 客户主键
  ,
  cm.code              AS code             -- 客户编号 as 客户编号
  ,
  cm.name              AS name             -- 客户法定名称 as 客户名称
  ,
  cm.address            AS address          -- 注册地址 as 地址
  ,
  cm.artificial        AS artificial       -- 法定代表人姓名 as 法人代表
  ,
  ''    AS corp_type        -- 经济类型 as 企业类型
  ,
  cm.cust_type1         AS cust_type1       -- 所属集团 as 所属集团
  ,
  cm.cust_type2              AS cust_type2       -- 客户类型 as 主营业务
  ,
  ''            AS custmanager      -- 客户经理编号,客户经理姓名 as 客户经理
  ,
  decode(cm.deleted,'N','0','Y','1')              AS dr_flag          -- 封存标志 as 删除标志
  ,
  ''           AS fax              -- 传真 as 传真
  ,
  cm.main_org_id                   AS main_org_id      -- 主办机构编号,主办机构名称 as 主办机构
  ,
  cm.reg_capt AS reg_capt         -- 注册资本(万元) as 注册资本
  ,
  ''              AS zip              -- 邮编 as 邮编
  ,
  cm.certificate_code              AS certificate_code -- 组织机构代码 as 组织机构代码证编号
  ,
  ''                  AS email            -- Email as 电子邮件
  ,
  cm.loan_code           AS loan_code        -- 贷款卡卡号 as 贷款卡卡号
  ,
  cm.op_date            AS op_date          -- 创建日期 as 操作日期
  ,
  ''         AS telephone        -- 固定电话 as 联系电话
  ,
  cm.reg_code          AS reg_code         -- 证照号码 as 工商注册号
  ,
  ''        AS province         -- 省、直辖市，自治区 as 省
  ,
  ''            AS city             -- 市、地区，州，旗 as 市
  ,
  ''           AS is_stck_hldr     -- 是否本公司股东 as 是否本公司股东
  ,
  ''              AS corp_size        -- 企业规模 as 企业规模
  ,
  ''           AS amount_people    -- 员工人数 as 企业人数
  ,
  cm.main_oper_cost      AS manage_scope    --经营范围，为风险提供
  ,
  cm.found_date as found_date --成立日期 as 成立日期
  FROM   ri_custbaseinfo cm
/

